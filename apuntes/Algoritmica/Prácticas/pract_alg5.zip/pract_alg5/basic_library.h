//
// Created by manumarin on 18/05/24.
//

#ifndef PRACT_ALG5_BASIC_LIBRARY_H
#define PRACT_ALG5_BASIC_LIBRARY_H

using namespace std;

#include <iostream>
#include <vector>
#include <limits>

#endif //PRACT_ALG5_BASIC_LIBRARY_H
