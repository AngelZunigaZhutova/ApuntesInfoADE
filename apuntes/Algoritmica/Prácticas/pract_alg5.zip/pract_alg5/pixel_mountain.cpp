#include <iostream>
#include <vector>
#include <algorithm>
#define matriz vector<vector<int>>

using namespace std;

matriz EscalaPixelMountain(const matriz & mountain) {

    matriz Costes=mountain;
    
    for (int i = 1; i < Costes.size(); ++i) {
        for (int j = 0; j < Costes[0].size(); ++j) {
            int min_cost = Costes[i-1][j];  // Coste desde arriba
            if (j > 0) {
                min_cost = min(min_cost, Costes[i-1][j-1]);  // Coste desde arriba-izquierda
            }
            if (j < Costes[0].size() - 1) {
                min_cost = min(min_cost, Costes[i-1][j+1]);  // Coste desde arriba-derecha
            }
            Costes[i][j] = mountain[i][j] + min_cost;
        }
    }

    return Costes;
}

pair<int,vector<int>> RecuperarCamino(matriz Costes, matriz mountain){

    vector<int> Camino;
    int Cima= Costes.size()-1;
    int index=0;
    int minimo=Costes[Cima][index];
    
    for (int i=1;i<mountain[0].size();i++){
        if (minimo>Costes[Cima][i]){
            minimo=Costes[Cima][i];
            index=i;
        }
    }

    int principio=index;
    Camino.push_back(index);

    for (int i=Cima; i>0;i--){
        if(index>0 && Costes[i-1][index-1]==Costes[i][index]-mountain[i][index]){
            index-=1;
        }
        if(index<Costes[0].size() && Costes[i-1][index+1]==Costes[i][index]-mountain[i][index]){
            index+=1;
        }
        Camino.push_back(index);
    }
    return pair<int,vector<int>>(Costes[Costes.size()-1][principio],Camino);
}

int main() {
    vector<vector<int>> mountain = {
        {2,8,9,5,8},
        {4,4,6,2,3},
        {5,7,5,6,1},
        {3,2,5,4,8}
    };
    matriz Costes=EscalaPixelMountain(mountain);
    auto result = RecuperarCamino(Costes,mountain);

    cout << "La tabla nos queda de la siguiente forma: " << endl;
    for (int i=0; i<Costes.size(); i++){
        for (int j=0; j<Costes[0].size(); j++){
            cout << Costes[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
    cout << "El minimo esfuerzo necesario para escalar la mountain es de: " << result.first << endl << "El camino es : ";
    for (int i=0;i<result.second.size();i++){
        cout << result.second[i]<< " ";
    }
    cout << endl;
    
}
