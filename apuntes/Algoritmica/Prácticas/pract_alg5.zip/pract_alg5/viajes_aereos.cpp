#include "basic_library.h"

const int INF = numeric_limits<int>::max();

// Función para inicializar las matricesMV y prox_nodo con los viajes directos primero.
void viajes_directos(int n, const vector<vector<int>>& T, vector<vector<int>>&MV, vector<vector<int>>& prox_nodo) {
    for (int i = 0; i < n; ++i) { //Aquí se exponen los casos base que hemos hablado en la parte de la ecuación de recurrencia
        for (int j = 0; j < n; ++j) {
            if (i == j) {MV[i][i] = 0;  // Caso base: tiempo de viaje de una ciudad a sí misma es 0
            } else if (T[i][j] != INF) {MV[i][j] = T[i][j];  // Caso base: tiempo de viaje directo
                prox_nodo[i][j] = j;  // Inicializar prox_nodo para el camino directo
            } else {MV[i][j] = INF;
                prox_nodo[i][j] = -1;  // Indica que no hay camino directo
            }
        }
    }
}

// Algoritmo de Floyd modificado
void coste_optimo(int n, vector<vector<int>>& MV, vector<vector<int>>& prox_nodo, const vector<int>& E) {
    for (int k = 0; k < n; ++k) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                if (MV[i][k] != INF &&MV[k][j] != INF &&MV[i][k] +MV[k][j] + E[k] <MV[i][j]) {
                    MV[i][j] =MV[i][k] +MV[k][j] + E[k];
                    prox_nodo[i][j] = prox_nodo[i][k];
                }
            }
        }
    }
}

// Función recursiva para construir el camino óptimo de i a j
void camino_sol_rec(const vector<vector<int>>& prox_nodo, int i, int j, vector<int>& camino) {
    if (i == j) {
        camino.push_back(i);
        return;
    }
    if (prox_nodo[i][j] == -1) {
        return;  // No hay camino de i a j
    }
    camino.push_back(i);
    camino_sol_rec(prox_nodo, prox_nodo[i][j], j, camino);
}

// Función envolvente para la construcción del camino con función camino_sol_rec() de arriba
vector<int> camino_sol(const vector<vector<int>>& prox_nodo, int i, int j) {
    vector<int> camino;
    if (prox_nodo[i][j] == -1) {
        return camino;  // No hay camino de i a j
    }
    camino_sol_rec(prox_nodo, i, j, camino);
    return camino;
}

int main() {
    int n = 4;
    vector<vector<int>> T = {
            {0, 2, 1, 3},
            {7, 0, 9, 2},
            {2, 2, 0, 1},
            {3, 4, 8, 0}
    };
    vector<int> E = {1, 1, 1, 1};

    vector<vector<int>> MV(n, vector<int>(n, INF));
    vector<vector<int>> prox_nodo(n, vector<int>(n, -1));

    viajes_directos(n, T, MV, prox_nodo);
    coste_optimo(n, MV, prox_nodo, E);

    int i = 1, j = 2; //Lo hemos pensado para que las posiciones empiecen desde 0 hasta n-1, tener en cuenta por si se quiere probar.
    vector<int> caminoSol = camino_sol(prox_nodo, i, j);
    int tiempo_opt_global =MV[i][j];

    cout << "El tiempo óptimo de " << i << " a " << j << " es: " << tiempo_opt_global << endl;
    cout << "El camino óptimo de " << i << " a " << j << " es: ";
    for (int ciudad : caminoSol) {
        cout << ciudad << " ";
    }
    cout << endl;

    return 0;
}
