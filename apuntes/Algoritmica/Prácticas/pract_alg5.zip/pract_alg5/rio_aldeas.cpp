#include <iostream>
#include <vector>
#include <climits>
#include <algorithm>

using namespace std;

const int INF = INT_MAX;

// Función auxiliar para inicializar la matriz dp
void inicializarDP(vector<vector<int>>& dp, const vector<vector<int>>& C, int n) {
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            dp[i][j] = C[i][j];
        }
    }
}

// Calculamos el coste mínimo utilizando programación dinámica
void calcularCosteMinimo(vector<vector<int>>& dp, int n) {
    for (int longitud = 2; longitud <= n; ++longitud) {
        for (int i = 0; i <= n - longitud; ++i) {
            int j = i + longitud - 1;
            for (int k = i + 1; k < j; ++k) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j]);
            }
        }
    }
}

// Recupera el camino óptimo utilizando la matriz dp
vector<int> recuperarSolucion(const vector<vector<int>>& dp, int i, int j) {
    if (i == j) return {};
    for (int k = i + 1; k < j; ++k) {
        if (dp[i][j] == dp[i][k] + dp[k][j]) {
            vector<int> izquierda = recuperarSolucion(dp, i, k);
            vector<int> derecha = recuperarSolucion(dp, k, j);
            izquierda.push_back(k);
            izquierda.insert(izquierda.end(), derecha.begin(), derecha.end());
            return izquierda;
        }
    }
    return {};
}

int main() {
    int n = 5;
    vector<vector<int>> C = {
            {0, 3, 3, INF, INF},
            {INF, 0, 4, 7, INF},
            {INF, INF, 0, 2, 3},
            {INF, INF, INF, 0, 2},
            {INF, INF, INF, INF, 0}
    };

    vector<vector<int>> dp(n, vector<int>(n, INF));
    inicializarDP(dp, C, n);
    calcularCosteMinimo(dp, n);

    int inicio = 0, fin = 4;
    cout << "Coste mínimo de " << inicio + 1 << " a " << fin + 1 << ": " << dp[inicio][fin] << endl;

    vector<int> camino = recuperarSolucion(dp, inicio, fin);
    cout << "Camino óptimo: " << inicio + 1 << " ";
    for (int i = 0; i < camino.size(); ++i) {
        cout << camino[i] + 1 << " ";
    }

    cout << fin + 1 << endl;

    return 0;
}
