#include <iostream>
#include <vector>
#include <string>
#include <fstream>

using namespace std;

void max( int hi, int hd, int ha, string & mov){
	if (hi >= hd) {
		if (hi >= ha) {
			mov = "izquierda";
		}
		else mov = "abajo";
	}
	else if (hd >= ha) {
		mov = "diagonal";
	}
	else mov = "abajo";
}

int camino_PD( int **m, int size, int &mon, vector<string> &ruta, int fil, int col){
	int hi = 0, hd = 0, ha = 0;
	if (fil == size-1 && col == 0) return 0;
	
	//Todos los caminos
	//izq
	int fili = fil;
	int coli = col - 1;
	if (coli < 0) hi = -10;
	if (m[fili][coli] == 2) hi = -10;
	
	//diagonal
	int fild = fil + 1;
	int cold = col - 1;
	if (fild >= size) hd = -10;
	if (cold < 0) hd = -10;
	if (m[fild][cold] == 2) hd = -10;
	
	//abajo
	int fila = fil + 1;
	int cola = col;
	if (fila >= size) ha = -10;
	if (m[fila][cola] == 2) ha = -10;
	
	//Heurísticas
	//izq
	for (int i = fili; i < size; i++) {
		for (int j = 0; j <= coli; j++) if (m[i][j] == 1) hi++;
	}
	
	//diagonal
	for (int i = fild; i < size; i++) {
		for (int j = 0; j <= cold; j++) if (m[i][j] == 1) hd++;
	}
	
	//abajo
	for (int i = fila; i < size; i++) {
		for (int j = 0; j <= cola; j++) if (m[i][j] == 1) ha++;
	}
	
	string mov;
	int aux = -1;
	while (aux != 0) {
		if (aux == 1) {
			if (mov == "izquierda") hi = -10;
			if (mov == "diagonal") hd = -10;
			if (mov == "abajo") ha = -10;
		}
		
		//Sino hay camino válido
		if (hi < 0 && hd < 0 && ha < 0) return 1;
		
		max(hi, hd, ha, mov);
		
		if (mov == "izquierda") aux = camino_PD(m, size, mon, ruta, fili, coli);
		else if (mov == "diagonal") aux = camino_PD(m, size, mon, ruta, fild, cold);
		else if (mov == "abajo") aux = camino_PD(m, size, mon, ruta, fila, cola);
	}
	
	//Cambiamos las monedas
	if (mov == "izquierda") {
		if (m[fili][coli] == 1) mon++;
	}
	else if (mov == "diagonal") {
		if (m[fild][cold] == 1) mon++;
	}
	else if (mov == "abajo") {
		if (m[fila][cola] == 1) mon++;
	}
	
	ruta.push_back(mov);
	return aux;
}


int main() {
    // Definir la matriz
    int size = 5;
    int **m = new int*[size];
    for (int i = 0; i < size; i++) {
        m[i] = new int[size];
    }
    m[0][0] = 1; m[0][1] = 0; m[0][2] = 2; m[0][3] = 0; m[0][4] = 0;
    m[1][0] = 0; m[1][1] = 1; m[1][2] = 1; m[1][3] = 0; m[1][4] = 0;
    m[2][0] = 0; m[2][1] = 0; m[2][2] = 1; m[2][3] = 0; m[2][4] = 0;
    m[3][0] = 0; m[3][1] = 0; m[3][2] = 1; m[3][3] = 0; m[3][4] = 0;
    m[4][0] = 0; m[4][1] = 0; m[4][2] = 0; m[4][3] = 0; m[4][4] = 0;

    //Imprimir la matriz
    cout << "Matriz de la que partimos: " << endl;
    for (int i = 0; i < size; i++) {
    	for (int j = 0; j < size; j++) cout << m[i][j] << " ";
    	cout << endl;
    }
    
    // Inicializar otras variables
    int mon = 0;
    vector<string> ruta;

    int posf = 0;
   int  posc = size - 1;
    // Llamar a la función para resolver el problema
    int resultado = camino_PD(m, size, mon, ruta, posf, posc);
    
    // Imprimir resultados
    if (resultado == 0) {
        cout << "Se encontró una solución." << endl;
        cout << "Número de monedas recogidas: " << mon << endl;
        cout << "Ruta óptima: " << endl;
        for (int i = ruta.size() - 1; i >= 0; i--) cout << ruta.at(i) << "    ";
        cout << endl;
    } else {
        cout << "No se encontró una solución." << endl;
    }

    // Liberar memoria
    for (int i = 0; i < size; i++) delete[] m[i];
    delete[] m;

    return 0;
}

