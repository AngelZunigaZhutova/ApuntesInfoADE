//
// Created by manumarin on 28/03/24.
//

#ifndef PRACT_ALG2_BASIC_LIBRARY_H
#define PRACT_ALG2_BASIC_LIBRARY_H

#include <cstdlib> // Para usar srand y rand
#include <chrono>
#include <iostream>
#include <fstream> // Para usar ficheros
#include <random>
#include <algorithm>

using namespace std;

#endif //PRACT_ALG2_BASIC_LIBRARY_H
