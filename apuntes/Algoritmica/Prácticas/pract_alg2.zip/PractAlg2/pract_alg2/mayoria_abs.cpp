#include <iostream>
#include <vector>
#include <unordered_map>
#include <random>
#include <string>
#include <chrono>
#include <fstream> // Para usar ficheros

using namespace std;


// Función para encontrar la mayoría absoluta con método propio (O(n))
int may_abs1(vector<int> votos) {
    unordered_map<int, int> frecuencia;

    // Paso 1: Conteo de frecuencias
    for (int voto : votos) {
        frecuencia[voto]++;
    }

    // Paso 2: Verificación de mayoría absoluta
    int n = votos.size();
    for (auto& par : frecuencia) {
        if (par.second > n / 2) {
            return par.first; // Se encontró la mayoría absoluta
        }
    }

    // Paso 3: Si no hay mayoría absoluta
    return -1;
}


// Función para encontrar la mayoría absoluta por fuerza bruta (O(n²))
int may_abs2(vector<int> votos) {
    int n = votos.size();
    
    //Paso 1: dos bucles anidados que recorran todo el vector
    for (int i = 0; i < n; i++) {
    	int cont = 0;
    	for (int j = 0; j < n; j++) {
            //Paso 2: Incremento el contador de los votos para comprobar si tienen mayoría absoluta
    	    if (votos[i] == votos[j]) cont++; 
    	}
    	if (cont > n/2) return votos[i];
    }
    
    // Paso 3: Si no hay mayoría absoluta
    return -1;
}


//Método para encontrar la mayoría absoluta con método dyv

//Función auxiliar
int contarFrecuencia(vector<int>& votos, int candidato) {
    int contador = 0;
    for (int voto : votos) {
        if (voto == candidato) {
            contador++;
        }
    }
    return contador;
}

// Función para encontrar la mayoría absoluta utilizando Divide y Vencerás
int mayoriaAbsolutaDivideYVenceras(vector<int>& votos, int inicio, int fin) {
    // Caso base: Si solo hay un voto, ese voto es la mayoría absoluta
    if (inicio == fin) {
        return votos[inicio];
    }

    // Dividir el conjunto de votos en dos mitades
    int mitad = (inicio + fin) / 2;

    // Recursión en ambas mitades
    int candidatoIzquierda = mayoriaAbsolutaDivideYVenceras(votos, inicio, mitad);
    int candidatoDerecha = mayoriaAbsolutaDivideYVenceras(votos, mitad + 1, fin);

    // Combinar las soluciones parciales
    if (candidatoIzquierda == candidatoDerecha) {
        return candidatoIzquierda; // Ambos subconjuntos tienen el mismo candidato
    }

    // Verificar si alguno de los candidatos es mayoría absoluta en el conjunto completo
    int frecuenciaIzquierda = contarFrecuencia(votos, candidatoIzquierda);
    int frecuenciaDerecha = contarFrecuencia(votos, candidatoDerecha);

    int n = fin - inicio + 1;
    if (frecuenciaIzquierda > n / 2) {
        return candidatoIzquierda;
    }
    if (frecuenciaDerecha > n / 2) {
        return candidatoDerecha;
    }

    // Si ninguno es mayoría absoluta en el conjunto completo, retornar -1
    return -1;
}

int may_abs_dyv(vector<int>& votos) {
    return mayoriaAbsolutaDivideYVenceras(votos, 0, votos.size() - 1);
}




int main(int argc, char *argv[]) {
    // Semilla para el generador de números aleatorios
    random_device rd;
    // Generador de números aleatorios
    mt19937 gen(rd());
    // Distribución uniforme entre 1 y 3
    uniform_int_distribution<> distribucion(1, 3);
    chrono::time_point<std::chrono::high_resolution_clock> t01, t02, t03, tf1, tf2, tf3; 
    // Para medir el tiempo de ejecución (lo de arriba)
    ofstream fsalida;

    if (argc <= 2) {
        cerr << "\nError: El programa se debe ejecutar de la siguiente forma.\n\n";
        cerr << argv[0] << " NombreFicheroSalida tam1 tam2 tam3 ... \n\n";
        //No pasarse de 7 dígitos o tarda mucho
        return 0;
    }
    
    // Abrimos fichero de salida
    fsalida.open(argv[1]);
    if (!fsalida.is_open()) {
        cerr << "Error: No se pudo abrir fichero para escritura " << argv[1] << "\n\n";
        return 0;
    }
    
    int argumento;
    for (argumento = 2; argumento < argc; argumento++) {
        // Tamaño del vector especificado por el usuario
        int tam = atoi(argv[argumento]);
        // Vector para almacenar los números aleatorios
        vector<int> votos;
        
        // Generar números aleatorios y añadirlos al vector
        for (int i = 0; i < tam; ++i) {
           votos.push_back(distribucion(gen));
        }
        
        
        //Método Normal (O(n))
        t01 = std::chrono::high_resolution_clock::now(); 
        // Cogemos el tiempo en que comienza la ejecución del algoritmo
        int mayoria1 = may_abs1(votos);
        tf1 = std::chrono::high_resolution_clock::now(); 
        // Cogemos el tiempo en que finaliza la ejecución del algoritmo
        unsigned long tejecucion1 = std::chrono::duration_cast<std::chrono::microseconds>(tf1 - t01).count();
        
         //Método Normal (O(n²))
        t02 = std::chrono::high_resolution_clock::now(); 
        // Cogemos el tiempo en que comienza la ejecución del algoritmo
        int mayoria2 = may_abs2(votos);
        tf2 = std::chrono::high_resolution_clock::now(); 
        // Cogemos el tiempo en que finaliza la ejecución del algoritmo
        unsigned long tejecucion2 = std::chrono::duration_cast<std::chrono::microseconds>(tf2 - t02).count();
        
        //Método DyV
        t03 = std::chrono::high_resolution_clock::now(); 
        // Cogemos el tiempo en que comienza la ejecución del algoritmo
        int mayoria3 = may_abs_dyv(votos);
        tf3 = std::chrono::high_resolution_clock::now(); 
        // Cogemos el tiempo en que finaliza la ejecución del algoritmo
        unsigned long tejecucion3 = std::chrono::duration_cast<std::chrono::microseconds>(tf3 - t03).count();
        
        // Guardamos tam. de caso y t_ejecucion a fichero de salida
        fsalida <<  "normal (map)" << tam << " " << tejecucion1 << "\n";
        fsalida <<  "normal (fuerza bruta) " << tam << " " << tejecucion2 << "\n";
        fsalida <<  "dyv " << tam << " " << tejecucion3 << "\n";
         
        //Salida por pantalla
        cout << "Para el tamaño " << tam << ":\n";
        if (mayoria1 != -1 && mayoria2 != -1 && mayoria3!= -1) {
            cout << "El candidato " << mayoria1 << " tiene mayoría absoluta." << endl;
        } else  {
            cout << "No hay mayoría absoluta." << endl;
          }
    }
    
    fsalida.close();
    
    return 0;
}

