// Función para intercambiar
#include "basic_library.h"

//////////////////////////////////////////////
////////////ALGORITMO ITERATIVO///////////////
//////////////////////////////////////////////

//Funcion auxiliar que se puede utilizar, con pretension de eliminar lineas en OrdenaCajonIter,
//pero preferimos dejar todo en la otra funcion para que sea más intuitivo y fácil de redactar en la memoria


bool intercambio_iter(int *cajon1, int *cajon2, int pos_fija, int pos_var){
    bool encontrado = false;
    if (cajon1[pos_fija] == cajon2[pos_var]) { //Si se encuentra tuerca de respectivo tornillo
        if (pos_fija != pos_var) {   //Si están en posiciones diferentes, se intercambian posiciones
            swap(cajon2[pos_fija], cajon2[pos_var]);
        }   //Si están en misma posición con mismo valor no se hace nada
        encontrado = true;  //Actualizamos valor de encontrado, hemos encontrado una tuerca para un tornillo
    }
    return encontrado;
}


void OrdenaCajonIter(int *cajon1, int *cajon2, int tam_caso){
    bool encontrado=false;
    for(int i=0;i<tam_caso;i++) { //Recorremos tuercas(tornillos)
        encontrado=false;
        for (int j = 0; j < tam_caso && !encontrado; j++) {
            if(cajon1[i]==cajon2[j]){
                if(i!=j){
                    swap(cajon2[i],cajon2[j]);
                    encontrado=true;
                }
            }
        }       //Recorremos tornillos(tuercas) para ver si se encaja con nuestro respectivo (tornillo/tuerca)
    }
}



//////////////////////////////////////////////
////////////ALGORITMO RECURSIVO///////////////
////////////(DIVIDE Y VENCERÁS)///////////////
//////////////////////////////////////////////


int partir(int *cajon1, int *cajon2, int primero, int ultimo, int pivote) {  //Muy parecido al partir clasico de quicksort (tambien se podria hacer con los while de las transparencias de prado),
    // pensamos más intuitiva esta manera con dos contadores comparativos de elementos del array y pivote
    int elem_pivote = cajon1[pivote], i = primero; //elem_pivote: Hacemos que nuestro elemento de pivote sea el cajon1[pivote]
    // i: Este contador se encontrara en la pos del primer elemento

    for (int j = primero; j <ultimo; j++) { // Sin embargo, este contador empezará en la posición siguiente al primer elemento, permitienedonos asi hacer comparaciones entre v[i] y v[j], adquiriendo j valores mayores que i.
        //MUY IMPORTANTE: mandar el elemento pivote al final del puntero primero, y no al final, pues puede dar lugar a redundancia y ser hasta más ineficiente que el algoritmo iterativo (habla la voz de la experiencia)

        if (cajon2[j] ==elem_pivote) {       //Si damos con el elemento del vector que es igual a nuestro elemento pivote:
            swap(cajon2[j],cajon2[ultimo]);       //Lo intercambiamos con el elemnto de pos final, y lo dejamos al fondo para separa el pivote en el final
        }                                                    // (el cual volveremos a poner en su pos en el main)
        if (cajon2[j] <= elem_pivote) { //Si el elemento  v2[j] es menor que el elemento escogido para pivotar(v1[ult]:
            swap(cajon2[i], cajon2[j]); //Intercambiamos elementos de pos i y j
            i++;                              //Incrementamos i para poder seguir haciendo comparaciones
        }

    }
    swap(cajon2[i],cajon2[ultimo]); //Tras obtener la posición del pivote, intercambiamos el elemento entre las posiciones i y ultimo, para hacer que el elem_pivote (el cual está en la derecha al final) se
    // se encuentre en la pos de pivote, y el elemento en la pos pivote pase al final con su grupo correspondiente

    return i;           // Devolvemos como valor i, que es la posicion donde se ha parado el contador primero ( donde ahora estará nuestro pivote)
}



void OrdenaCajonRec(int *tuercas, int *tornillos, int izda, int dcha){
    if (izda < dcha){//Muy imp que para ambos pasemos como pos pivote dcha, pues los dos swaps que hacemos después son entre la dcha y la pos `pivote
        partir(tuercas, tornillos, izda, dcha, dcha); //Pasamos como pivote la derecha en ambos casos; devuelve pos pivote y divide vector en grupo
        int pivote = partir(tornillos, tuercas, izda, dcha, dcha); //mayores y grupo menores
        OrdenaCajonRec(tuercas, tornillos, izda, pivote - 1); //CRUCIAL: llamamos a nuestro algoritmo para que haga lo mismo recursivamente
        OrdenaCajonRec(tuercas, tornillos, pivote + 1, dcha);  // con cada uno de los dos grupos divididos del vector (grupo mayores y grupo menores)
    }
}



//////////////////////////////////////////////
////////////FUNCIONES AUX MAIN////////////////
//////////////////////////////////////////////

bool iguales(int *v1, int *v2,int n){  //Dice si dos punteros del mismo tamaño son iguales
    bool iguales=true;
    for(int i=0; i<n && iguales; i++){
        if(v1[i]!=v2[i]) iguales=false;
    }
    return iguales;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main(int argc, char *argv[]){
    int n, i, argumento;
    chrono::time_point<std::chrono::high_resolution_clock> t0, tf; // Para medir el tiempo de ejecuciÃ³n
    unsigned long int semilla;
    ofstream fsalidaiterativo,fsalidarecursivo;
    unsigned long tejecucion;

    if (argc <= 4) {
        cerr<<"\nError: El programa se debe ejecutar de la siguiente forma.\n\n";
        cerr<<argv[0]<<" NombreFicheroSalidaIterativo NombreFicheroSalidaRecursivo Semilla tamCaso1 tamCaso2 ... tamCasoN\n\n";
        return 0;
    }

    // Abrimos fichero de salida
    fsalidaiterativo.open(argv[1]);
    if (!fsalidaiterativo.is_open()) {
        cerr<<"Error: No se pudo abrir fichero iterativo para escritura "<<argv[1]<<"\n\n";
        return 0;
    }

    fsalidarecursivo.open(argv[2]);
    if (!fsalidarecursivo.is_open()) {
        cerr<<"Error: No se pudo abrir fichero iterativo para escritura "<<argv[2]<<"\n\n";
        return 0;
    }

    // Inicializamos generador de no. aleatorios
    semilla= atoi(argv[3]);
    srand(semilla);

    // Pasamos por cada tamaÃ’o de caso
    for (argumento= 4; argumento<argc; argumento++) {

        // Cogemos el tamanio del caso
        n= atoi(argv[argumento]);

        // Reservamos memoria para el vector
        int *tuercas = new int[n];
        int *tornillos = new int[n];
        int *tuercas2 = new int[n];
        int *tornillos2 = new int[n];

        vector<int> elem_yapresentes(n);
        // Generamos vector aleatorio de prueba, con componentes entre 0 y n-1
        for (i= 0; i<n; i++) {
            int j;
            do {
                j = rand() % n;
            }while(std::count(elem_yapresentes.begin(), elem_yapresentes.end(),j)!=0);  // Para asegurar que todos los elementos sean diferentes
            tuercas[i]= j;      //Ambos vectores de tuercas iguales para que la comparacion sea buena
            tuercas2[i]= j;
            tornillos[i]= j;    //Llenamos de numeros el vector de tornillos
        }

        //Generamos aleatoriamente
        random_device rd;
        default_random_engine rng(rd());
        do {
            shuffle(tornillos, tornillos + n, rng); //desordenamos el vector de tornillos para que tenga un orden diferente al de tuercas
        }while(iguales(tuercas,tornillos,n));

        for(int i=0; i<n; i++) {
            tornillos2[i]=tornillos[i]; // copiamos el contenido del puntero de tornillos a tornillos2 para que sean iguales
        }

        cerr << "Ejecutando Divide y venceras Iterativo para tam. caso: " << n << endl;

        t0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÃ›n del algoritmo
        OrdenaCajonIter(tuercas2,tornillos2,n); // Ejecutamos el algoritmo para tamaÃ’o de caso tam
        tf= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÃ›n del algoritmo

        tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf - t0).count();

        cerr << "\tTiempo de ejec. (us): " << tejecucion << " para tam. caso "<< n<<endl;

        // Guardamos tam. de caso y t_ejecucion a fichero de salida
        fsalidaiterativo<<n<<" "<<tejecucion<<"\n";

        cerr << "Ejecutando Divide y venceras Recursivo para tam. caso: " << n << endl;

        t0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÃ›n del algoritmo
        OrdenaCajonRec(tuercas,tornillos,0,n-1); // Ejecutamos el algoritmo para tamaÃ’o de caso tam
        tf= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÃ›n del algoritmo

        tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf - t0).count();

        cerr << "\tTiempo de ejec. (us): " << tejecucion << " para tam. caso "<< n<<endl;

        // Guardamos tam. de caso y t_ejecucion a fichero de salida
        fsalidarecursivo<<n<<" "<<tejecucion<<"\n";

        delete[] tuercas;
        delete[] tuercas2;
        delete[] tornillos;
        delete[] tornillos2;
    }

    // Cerramos fichero de salida
    fsalidarecursivo.close();
    fsalidaiterativo.close();

    return 0;
}


