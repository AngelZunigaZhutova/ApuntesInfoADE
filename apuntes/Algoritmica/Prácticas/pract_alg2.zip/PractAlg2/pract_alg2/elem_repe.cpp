//
// Created by manumarin on 27/03/24.
//
#include "basic_library.h"
#include <vector>
#include <algorithm>

using namespace std;

void eliminarRepetidosIterativo(vector<int>& vec){
    vector<int> copia;//Creamos un vector copia donde incluiremos unicamente los elementos no repetidos
    copia.push_back(vec[0]); 
    for (int i=1; i<vec.size();i++){ //Recorremos nuestro vector original
        if (find(copia.begin(),copia.end(),vec[i]) == copia.end()){ //Comprobamos que elementos no estan repetidos
            copia.push_back(vec[i]); //Copiamos unicamente aquellos que no aparezcan en nuestro vector copia
        }
    }
    vec=copia; //Sustituimos nuestro vector original por el nuevo
}

vector<int> eliminarRepetidosRecursivo(vector<int>& vec, int n){
    if (vec.size()==n){
		sort(vec.begin(),vec.end()); //Ordenamos los elementos de nuestro vector original para que no pueda haber elementos repetidos en las dos mitades
	}

	if (vec.size()>1){ 
		if (count(vec.begin(),vec.end(),vec[0])==vec.size()){ //Cuando llegue un momento en que el vector este unicamente formado por el mismo número, eliminamos las repeticiones de este
			while (vec.size()>1){
				vec.pop_back();
			}
		}
		else{
			vector<int>::iterator pivote=find(vec.begin(),vec.end(),vec[vec.size()/2]); //Buscamos la mediana de nuestro vector, para dividirlo a partir de ahí
			if (pivote==vec.begin()){ //Si la mediana se repite, y coincide con el primer elemento del vector, cambiamos a la ultima repetición de esta
				pivote+=count(vec.begin(),vec.end(),*pivote);
			}
			vector<int> izquierda(vec.begin(),pivote),derecha(pivote,vec.end()); //Dividos el vector principal en dos mitades

			izquierda=eliminarRepetidosRecursivo(izquierda,n); //Llamamos recursivamente a nuestra función en ambas mitades
			derecha=eliminarRepetidosRecursivo(derecha,n);
			vector<int> mezcla(izquierda.size()+derecha.size()); //Mezclamos ambas mitades
			merge(izquierda.begin(),izquierda.end(),derecha.begin(),derecha.end(),mezcla.begin());

			vec=mezcla;//Devolvemos las dos mitades unidas a nuestro vector original
		}
	}
	return vec;
}

int main(int argc, char *argv[]) {
	
	int n, i, argumento;
    chrono::time_point<std::chrono::high_resolution_clock> t0, tf; // Para medir el tiempo de ejecuciÃ³n
	unsigned long int semilla;
	ofstream fsalidaiterativo,fsalidarecursivo;
    unsigned long tejecucion;
	
	if (argc <= 4) {
		cerr<<"\nError: El programa se debe ejecutar de la siguiente forma.\n\n";
		cerr<<argv[0]<<" NombreFicheroSalidaIterativo NombreFicheroSalidaRecursivo Semilla tamCaso1 tamCaso2 ... tamCasoN\n\n";
		return 0;
	}
	
	// Abrimos fichero de salida
	fsalidaiterativo.open(argv[1]);
	if (!fsalidaiterativo.is_open()) {
		cerr<<"Error: No se pudo abrir fichero iterativo para escritura "<<argv[1]<<"\n\n";
		return 0;
	}

    fsalidarecursivo.open(argv[2]);
	if (!fsalidarecursivo.is_open()) {
		cerr<<"Error: No se pudo abrir fichero iterativo para escritura "<<argv[2]<<"\n\n";
		return 0;
	}
	
	// Inicializamos generador de no. aleatorios
	semilla= atoi(argv[3]);
	srand(semilla);
	
	// Pasamos por cada tamaÃ’o de caso
	for (argumento= 4; argumento<argc; argumento++) {
		
		// Cogemos el tamanio del caso
		n= atoi(argv[argumento]);

        vector<int> v(n),v2(n);
		
		// Generamos vector aleatorio de prueba, con componentes entre 0 y n-1
		for (i= 0; i<n; i++)
			v[i]= rand()%n;
		
        v2=v;
		cerr << "Ejecutando Elementos repetidos Iterativo para tam. caso: " << n << endl;
		
		t0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÃ›n del algoritmo
		eliminarRepetidosIterativo(v); // Ejecutamos el algoritmo para tamaÃ’o de caso tam
		tf= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÃ›n del algoritmo
		
		tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf - t0).count();
		
		cerr << "\tTiempo de ejec. (us): " << tejecucion << " para tam. caso "<< n<<endl;
		
		// Guardamos tam. de caso y t_ejecucion a fichero de salida
		fsalidaiterativo<<n<<" "<<tejecucion<<"\n";

        cerr << "Ejecutando Elementos repetidos Divide y venceras para tam. caso: " << n << endl;
		
		t0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÃ›n del algoritmo
		v2=eliminarRepetidosRecursivo(v,v.size()); // Ejecutamos el algoritmo para tamaÃ’o de caso tam
		tf= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÃ›n del algoritmo
		
		tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf - t0).count();
		
		cerr << "\tTiempo de ejec. (us): " << tejecucion << " para tam. caso "<< n<<endl;
		
		// Guardamos tam. de caso y t_ejecucion a fichero de salida
		fsalidarecursivo<<n<<" "<<tejecucion<<"\n";
	}
	
	// Cerramos fichero de salida
	fsalidarecursivo.close();
    fsalidaiterativo.close();
	
	return 0;
}