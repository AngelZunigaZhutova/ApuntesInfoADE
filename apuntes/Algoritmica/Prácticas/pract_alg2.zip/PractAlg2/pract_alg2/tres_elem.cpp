#include <iostream>
#include <chrono>
#include <fstream>

using namespace std;

bool Producto_de_tres_consecutivos_sin_DV(long long int N) {
    // Vamos a ver primero los casos en los que sabemos que N
    // no es producto de tres números consecutivos

    // El menor número posible es 6 (1*2*3=6)
    if (N < 6) 
        return false;
    
    // Si no es múltiplo de 3
    if (N % 3 != 0) 
        return false;

    // Iteramos hasta N/3 ya que como hemos visto antes si no es múltiplo de 3 no es producto de 3
    for (int i = 1; i <= N / 3; i++) {
        // Verificamos si el producto de tres números consecutivos es igual a N
        if (i * (i + 1) * (i + 2) == N) {
            return true;
        }
    }

    return false;
}

bool Producto_de_tres_DV(long long int N, long long int principio, long long int fin) {
    if (N < 6)
        return false;

    if (N % 3 != 0)
        return false;

    if (principio >= fin) {
        return false;
    }

    int mitad = principio + (fin - principio) / 2;

    // Verificar si el producto de los tres números consecutivos cae dentro de la mitad actual
    long long int producto = (long long int)mitad * (mitad + 1) * (mitad + 2);

    if (producto == N) {
        return true;
    } else if (producto < N) {
        // Si el producto es menor que N, buscar en la mitad derecha
        return Producto_de_tres_DV(N, mitad + 1, fin);
    } else {
        // Si el producto es mayor que N, buscar en la mitad izquierda
        return Producto_de_tres_DV(N, principio, mitad);
    }
}

int main(int argc, char *argv[]) {
	bool iter=false,dyv=false;
	int n, i, argumento;
    chrono::time_point<std::chrono::high_resolution_clock> t0, tf; // Para medir el tiempo de ejecuciÃ³n
	unsigned long int semilla;
	ofstream fsalidaiterativo,fsalidarecursivo;
    unsigned long tejecucion;
	
	if (argc <= 3) {
		cerr<<"\nError: El programa se debe ejecutar de la siguiente forma.\n\n";
		cerr<<argv[0]<<" NombreFicheroSalidaIterativo NombreFicheroSalidaRecursivo tamCaso1 tamCaso2 ... tamCasoN\n\n";
		return 0;
	}
	
	// Abrimos fichero de salida
	fsalidaiterativo.open(argv[1]);
	if (!fsalidaiterativo.is_open()) {
		cerr<<"Error: No se pudo abrir fichero iterativo para escritura "<<argv[1]<<"\n\n";
		return 0;
	}

    fsalidarecursivo.open(argv[2]);
	if (!fsalidarecursivo.is_open()) {
		cerr<<"Error: No se pudo abrir fichero recursivo para escritura "<<argv[2]<<"\n\n";
		return 0;
	}
	
	// Pasamos por cada tamaÃ’o de caso
	for (argumento= 3; argumento<argc; argumento++) {
		
		// Cogemos el tamanio del caso
		n= atoi(argv[argumento]);
		
		cerr << "Ejecutando Producto de tres Iterativo para tam. caso: " << n << endl;
		
		t0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÃ›n del algoritmo
		iter=Producto_de_tres_consecutivos_sin_DV(n); // Ejecutamos el algoritmo para tamaÃ’o de caso tam
		tf= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÃ›n del algoritmo
		
		tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf - t0).count();
		
		cerr << "\tTiempo de ejec. (us): " << tejecucion << " para tam. caso "<< n<<endl;
        if (iter){
            cerr<<"Encontrado" << endl;
        } else {
            cerr << "No encontrado" << endl;
        }
		iter=false;
		// Guardamos tam. de caso y t_ejecucion a fichero de salida
		fsalidaiterativo<<n<<" "<<tejecucion<<"\n" << "\n";

        cerr << "Ejecutando Producto de tres Divide y venceras para tam. caso: " << n << endl;
		
		t0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÃ›n del algoritmo
		dyv=Producto_de_tres_DV(n,1, n/3); // Ejecutamos el algoritmo para tamaÃ’o de caso tam
		tf= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÃ›n del algoritmo
		
		tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf - t0).count();
		
		cerr << "\tTiempo de ejec. (us): " << tejecucion << " para tam. caso "<< n<<endl;
        if (dyv){
            cerr<<"Encontrado" << endl;
        } else {
            cerr << "No encontrado" << endl;
        }
        dyv=false;
		
		// Guardamos tam. de caso y t_ejecucion a fichero de salida
		fsalidarecursivo<<n<<" "<<tejecucion<<"\n" << "\n";
	}
	
	// Cerramos fichero de salida
	fsalidarecursivo.close();
    fsalidaiterativo.close();
	
	return 0;
}