//
// Created by manumarin on 28/03/24.
//

#include "basic_library.h"
#include <iostream>
#include <vector>
#include <cstdlib>
#include <algorithm>

using namespace std;

void CalendarioCampeonatoIterativo(vector<vector<int>>& m){
    bool salir=false;
    for(int i=1; i<m.size(); i++){
        m[0][i-1]=i;
        m[(m[0][i-1])][i-1]=0;
    }

    for (int i=1; i<m.size();i++){
        for (int j=0; j<m[0].size();j++){
            if (m[i][j]==-1){
                for( int k=i+1; k<m.size() && !salir;k++){
                    if (m[k][j]==-1 && (find(m[i].begin(),m[i].end(),k)==m[i].end())){
                        m[i][j]=k;
                        m[k][j]=i;
                        salir=true;
                    }
                }
                salir=false;
            }
        }
    }
}

void Rellenar(vector<vector<int>>& m, int PrimerEq, int UltimoEq, int PrimerDia, int UltimoDia, int eqInicial) {
    for (int j = PrimerDia; j <= UltimoDia; j++) {
        m[PrimerEq][j] = eqInicial + j - PrimerDia;
    }
    for (int i = PrimerEq + 1; i <= UltimoEq; i++) {
        m[i][PrimerDia] = m[i - 1][UltimoDia];
        for (int j = PrimerDia + 1; j <= UltimoDia; j++) {
            m[i][j] = m[i - 1][j - 1];
        }
    }
}

void CalendarioCampeonatoDivideyVenceras(vector<vector<int>>& m, int primero, int ultimo) {
    if (ultimo - primero == 1) {
        m[primero][0] = ultimo;
        m[ultimo][0] = primero;
    } else {
        int medio = (primero + ultimo) / 2;
        CalendarioCampeonatoDivideyVenceras(m, primero, medio);
        CalendarioCampeonatoDivideyVenceras(m, medio + 1, ultimo);
        Rellenar(m, primero, medio, medio - primero, ultimo - primero-1, medio + 1);
        Rellenar(m, medio + 1, ultimo, medio - primero, ultimo - primero-1, primero);
    }
}

int main(int argc, char *argv[]) {
	
	int n, i, argumento;
    chrono::time_point<std::chrono::high_resolution_clock> t0, tf; // Para medir el tiempo de ejecuciÃ³n
	unsigned long int semilla;
	ofstream fsalidaiterativo,fsalidarecursivo;
    unsigned long tejecucion;
	
	if (argc <= 4) {
		cerr<<"\nError: El programa se debe ejecutar de la siguiente forma.\n\n";
		cerr<<argv[0]<<" NombreFicheroSalidaIterativo NombreFicheroSalidaRecursivo Semilla tamCaso1 tamCaso2 ... tamCasoN\n\n";
		return 0;
	}
	
	// Abrimos fichero de salida
	fsalidaiterativo.open(argv[1]);
	if (!fsalidaiterativo.is_open()) {
		cerr<<"Error: No se pudo abrir fichero iterativo para escritura "<<argv[1]<<"\n\n";
		return 0;
	}

    fsalidarecursivo.open(argv[2]);
	if (!fsalidarecursivo.is_open()) {
		cerr<<"Error: No se pudo abrir fichero iterativo para escritura "<<argv[2]<<"\n\n";
		return 0;
	}
	
	// Inicializamos generador de no. aleatorios
	semilla= atoi(argv[3]);
	srand(semilla);
	
	// Pasamos por cada tamaÃ’o de caso
	for (argumento= 4; argumento<argc; argumento++) {
		
		// Cogemos el tamanio del caso
		n= atoi(argv[argumento]);

        vector<vector<int>> v(n,vector<int>(n-1,-1)),v2(n,vector<int>(n-1,-1));
		
		cerr << "Ejecutando Calendario campeonato Iterativo para tam. caso: " << n << endl;
		
		t0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÃ›n del algoritmo
		CalendarioCampeonatoIterativo(v); // Ejecutamos el algoritmo para tamaÃ’o de caso tam
		tf= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÃ›n del algoritmo
		
		tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf - t0).count();
		
		cerr << "\tTiempo de ejec. (us): " << tejecucion << " para tam. caso "<< n<<endl;
		
		// Guardamos tam. de caso y t_ejecucion a fichero de salida
		fsalidaiterativo<<n<<" "<<tejecucion<<"\n";

        cerr << "Ejecutando Calendario campeonato Divide y venceras para tam. caso: " << n << endl;
		
		t0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÃ›n del algoritmo
		CalendarioCampeonatoDivideyVenceras(v2,0,v2.size()-1); // Ejecutamos el algoritmo para tamaÃ’o de caso tam
		tf= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÃ›n del algoritmo
		
		tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf - t0).count();
		
		cerr << "\tTiempo de ejec. (us): " << tejecucion << " para tam. caso "<< n<<endl;
		
		// Guardamos tam. de caso y t_ejecucion a fichero de salida
		fsalidarecursivo<<n<<" "<<tejecucion<<"\n";
	}
	
	// Cerramos fichero de salida
	fsalidarecursivo.close();
    fsalidaiterativo.close();
	
	return 0;
}