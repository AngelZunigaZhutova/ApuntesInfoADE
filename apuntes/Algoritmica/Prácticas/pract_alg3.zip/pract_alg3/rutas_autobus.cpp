#include "basic_library.h"

// Función que calcula las paradas de repostaje necesarias para recorrer una ruta en autobús
vector<int> repostaje_autobus(int km_ruta, int capacidad_deposito, vector<int>& gasolineras) {

    int km_recorridos = 0;
    vector<int> paradas;

    for (int gasolinera=0; gasolinera < gasolineras.size(); gasolinera++){
        // Si la distancia a la siguiente gasolinera es mayor que la capacidad del tanque,
        // necesitamos repostar en la gasolinera anterior

        if (gasolineras[gasolinera] - km_recorridos >  capacidad_deposito) {
            paradas.push_back(gasolineras[gasolinera-1]);
            km_recorridos = gasolineras[gasolinera-1]; // Actualizamos la distancia recorrida
        }
        else if(gasolineras[gasolinera] - km_recorridos ==  capacidad_deposito){
            paradas.push_back(gasolineras[gasolinera]);
            km_recorridos = gasolineras[gasolinera]; // Actualizamos la distancia recorrida
        }

    }

    // Si aún no hemos llegado al final de la ruta, necesitamos repostar en la última gasolinera
    if (km_ruta - km_recorridos >= capacidad_deposito) {
        paradas.push_back(km_recorridos);
        km_recorridos = gasolineras.back(); // Actualizamos la distancia recorrida
    }

    return paradas;
}

int main() {
    // Datos de entrada
    int km_ruta = 100;
    int capacidad_deposito = 50; // km de autonomía
    vector<int> gasolineras = {15,40,60,90}; // Ubicaciones de las gasolineras en kilómetros

    // Llamo a la función
    vector<int> paradas = repostaje_autobus(km_ruta, capacidad_deposito, gasolineras);

    // Imprimimos las paradas de repostaje necesarias
    cout << "Paradas de repostaje:" << endl;
    for (int parada = 0; parada < paradas.size(); parada++) {
        cout << paradas[parada] << " ";
    }
    cout << endl;


    return 0;
}
