#include "basic_library.h"

const int INF = numeric_limits<int>::max(); // Representación de infinito

// Estructura para representar un nodo en el grafo
struct Nodo {
    int id;
    vector<pair<int, int>> vecinos; // Pares (nodo vecino, tiempo de envío)
};

// Función para generar un grafo aleatorio con la cantidad de nodos especificada
vector<Nodo> generarGrafoAleatorio(int num_nodos) {
    srand(time(0));
    vector<Nodo> grafo(num_nodos);
    
    // Generar conexiones aleatorias entre los nodos
    for (int i = 0; i < num_nodos; ++i) {
        grafo[i].id = i;
        for (int j = i + 1; j < num_nodos; ++j) {
            if (rand() % 2 == 1) { // Aleatoriamente decidir si hay conexión entre los nodos
                int tiempo_envio = rand() % 10 + 1; // Tiempo de envío aleatorio entre 1 y 10
                grafo[i].vecinos.push_back({j, tiempo_envio});
                grafo[j].vecinos.push_back({i, tiempo_envio});
            }
        }
    }
    
    return grafo;
}

// Función para encontrar el camino más corto desde cada nodo hasta el nodo central utilizando el algoritmo de Dijkstra
vector<pair<int, vector<int>>> encontrarCaminoMasCorto(vector<Nodo>& grafo, int nodo_central) {
    int n = grafo.size();
    vector<int> distancia(n, INF); // Inicializamos todas las distancias como infinito
    vector<int> padre(n, -1); // Nodo predecesor en el camino más corto
    vector<bool> visitado(n, false); // Marcamos todos los nodos como no visitados
    
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq; // Utilizamos una cola de prioridad para almacenar los nodos ordenados por distancia

    distancia[nodo_central] = 0;
    pq.push({0, nodo_central});

    while (!pq.empty()) {
        int nodo_actual = pq.top().second;
        pq.pop();

        if (visitado[nodo_actual]) continue;
        visitado[nodo_actual] = true;

        for (auto vecino : grafo[nodo_actual].vecinos) {
            int nodo_vecino = vecino.first;
            int tiempo_envio = vecino.second;

            if (!visitado[nodo_vecino] && distancia[nodo_actual] + tiempo_envio < distancia[nodo_vecino]) {
                distancia[nodo_vecino] = distancia[nodo_actual] + tiempo_envio;
                padre[nodo_vecino] = nodo_actual;
                pq.push({distancia[nodo_vecino], nodo_vecino});
            }
        }
    }

    // Verificamos si hay un camino válido desde el nodo central a todos los demás nodos
    for (int i = 0; i < n; ++i) {
        if (distancia[i] == INF && i != nodo_central) { // Si alguna distancia sigue siendo infinita y no es el nodo central
            // No hay solución válida, devolvemos un resultado vacío
            return {};
        }
    }

    // Construimos y devolvemos el resultado
    vector<pair<int, vector<int>>> resultado;
    for (int i = 0; i < n; ++i) {
        vector<int> camino;
        int nodo_actual = i;
        while (nodo_actual != nodo_central) {
            camino.push_back(nodo_actual);
            nodo_actual = padre[nodo_actual];
        }
        camino.push_back(nodo_central);
        resultado.push_back({distancia[i], camino});
    }

    return resultado;
}


int main() {
    int num_nodos;
    cout << "Ingrese la cantidad de nodos en la red: ";
    cin >> num_nodos;
    
    // Generar el grafo aleatorio
    vector<Nodo> grafo = generarGrafoAleatorio(num_nodos);
    
    // Imprimir el grafo inicial
    cout << "Grafo inicial:" << endl;
    for (int i = 0; i < num_nodos; ++i) {
        cout << "Nodo " << grafo[i].id << ": ";
        for (auto vecino : grafo[i].vecinos) {
            cout << "(" << vecino.first << ", " << vecino.second << ") ";
        }
        cout << endl;
    }
    
    // Solicitar el nodo que actuará como servidor central
    int nodo_central;
    cout << "\nIngrese el nodo que actuará como servidor central (entre 0 y " << num_nodos - 1 << "): ";
    cin >> nodo_central;

    // Encontramos el camino más corto desde cada nodo hasta el nodo central utilizando Dijkstra
    vector<pair<int, vector<int>>> resultados = encontrarCaminoMasCorto(grafo, nodo_central);

    // Imprimimos las distancias desde cada nodo hasta el nodo central y los caminos más cortos
    cout << "\nDistancias desde cada nodo hasta el nodo central:" << endl;
    for (int i = 0; i < num_nodos; ++i) {
        cout << "Nodo " << i << ": " << resultados[i].first << ", Camino: ";
        for (int j = resultados[i].second.size() - 1; j >= 0; --j) {
            cout << resultados[i].second[j];
            if (j > 0) cout << " <- ";
        }
        cout << endl;
    }

    return 0;
}


