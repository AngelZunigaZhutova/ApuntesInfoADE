//
// Created by manumarin on 13/04/24.
//

#ifndef PRACT_ALG3_BASIC_LIBRARY_H
#define PRACT_ALG3_BASIC_LIBRARY_H

#include <iostream>
#include <string>
#include <map>
#include <set>
#include <vector>
#include <algorithm>
#include <cassert>
#include <limits>
#include <queue>
#include <cstdlib>

using namespace std;


#endif //PRACT_ALG3_BASIC_LIBRARY_H
