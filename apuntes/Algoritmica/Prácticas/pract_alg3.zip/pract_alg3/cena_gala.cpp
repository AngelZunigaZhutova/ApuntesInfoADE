//
// Created by manumarin on 13/04/24.
//
#include "basic_library.h"


//Como señalamos en la plantilla del algoritmo Greedy, vamos a usar como notación L para nuestra lista de invitados y M para reppresentar la mesa

// Selecciona el próximo candidato con la máxima conveniencia disponible
string funcion_seleccion(const set<string>& L, const vector<string>& M, const map<string, map<string, int>>& niv_conve) {
    string inv_max = "";
    int max_conv = -1;
    string ult_inv = M.empty() ? "" : M.back();

    for (const auto& invitado_i : L) {
        int conv_i= ult_inv.empty() ? 0 : niv_conve.at(ult_inv).at(invitado_i);
        if (conv_i > max_conv) {
            max_conv = conv_i;
            inv_max = invitado_i;
        }
    }
    return inv_max;
}

// Determina si la adición de un nuevo invitado es factible
bool factible(const string& invitado, const vector<string>& M, const map<string, map<string, int>>& niv_conve) {
    return ( M.empty() || !(niv_conve.at(M.back()).find(invitado) == niv_conve.at(M.back()).end()) );
}   //Si la mesa está vacía devolverá true, y verifica si existe un registro de conveniencia entre el candidato
    // y el último invitado colocado de la mesa


// Función Greedy para construir la mesa de solución
vector<string> Greedy(const vector<string>& L, const map<string, map<string, int>>& niv_conve) {
    vector<string> mesa;
    set<string> lista_invi(L.begin(), L.end());

    while (!L.empty() && mesa.size() < L.size()) {
        string inv_seleccionado = funcion_seleccion(lista_invi, mesa, niv_conve);
        if (factible(inv_seleccionado, mesa, niv_conve)) {
            mesa.push_back(inv_seleccionado);
            lista_invi.erase(inv_seleccionado);
        } else {
            cerr << "No se ha encontrado solución viable." << endl;
        }
    }

    return mesa;
}


//int main(){

    /*
     * MANERA PARA IR HACIENDOLO METIENDO VALORES POR CONSOLA (MUCHO MENOS CÓMODO)
    */
    /*
    int contador1,contador2;
    string name;
    vector<string> lista;
    vector<pair<pair<string,string>,int>> niveles_conve;
    char centinela='n';
    cout << "¿Cuántos invitados son?" << endl;
    cin >> contador1;
    contador2=contador1;
    cout << "Introduzca la lista de invitados" << endl;
    cout << "Nombres:" << endl;
    while(contador1>0){
        cin >> name;
        contador1--;
        lista.push_back(name);
    }
    while(centinela!='q') {
        string nombre1, nombre2;
        int conv=0;
        pair<pair<string,string>,int> aux_map;
        pair<string,string> aux_nombres;
        set <pair<string,string>> metidos;
        cout << "Introduzca las conveniencias entre invitados(nombre1 nombre2 int)" << endl;
        cin >> nombre1 >> nombre2 >> conv;
        aux_nombres.first=nombre1;
        aux_nombres.second=nombre2;
        if(!metidos.count(aux_nombres)){    //Para evitar repetidos
            aux_map.first=aux_nombres;
            aux_map.second=conv;
            metidos.insert(aux_nombres);
        }
        cout << "Si ha terminado, introduzca q" << endl;
        cin >> centinela;
    }
    */


/*
 * MANERA CÓMODA, DECLARAR EJEMPLO PEQUEÑO DESDE EL PRINCIPIO
 */

int main(){
    //Vease aquí nuestra lista de invitados
    vector<string> invitados = {"Antonio", "Beatriz", "Carlos", "Diego"};

    //Aquí declaramos nuestro map de parejas de invitados, y conveniencias entre ellos, el cual nos facilitará enormemente el algoritmo
    map<string, map<string, int>> niv_conve = {
            {"Antonio", {{"Beatriz", 20}, {"Carlos", 70}, {"Diego", 50}}},
            {"Beatriz", {{"Antonio", 20}, {"Carlos", 40}, {"Diego", 10}}},
            {"Carlos", {{"Antonio", 70}, {"Beatriz", 40}, {"Diego", 50}}},
            {"Diego", {{"Antonio", 50}, {"Beatriz", 10}, {"Carlos", 50}}}
    };

        cout << "Lista invitados:"<< endl;
        for (const auto& invitado_n : invitados)
            cout << invitado_n << " ";
        cout << endl;


    //Llamamos a nuestro algoritmo Greedy para que ordene la mesa con la lista de invitados
   vector <string> mesa = Greedy(invitados, niv_conve);

    if (!mesa.empty()) {
        cout << "Mesa final:" << endl;
        for (const auto& invitado_n : mesa)
            cout << invitado_n << " ";
        cout << endl;
    }else {
        cout << "No se ha encontrado mesa conveniente para la cena." << endl;
    }
    cout << endl;

    return 0;
}




