#include "basic_library.h"

#define vertice pair<pair<int,int>,int>

class Grafo {
private:
  struct Arista {
    int origen;
    int destino;
    int peso;

    Arista(int o, int d, int p) : origen(o), destino(d), peso(p) {}
  };

  vector<vector<int>> matrizAdyacencia;
  vector<vector<int>> listaAdyacencia;
  vector<Arista> aristas;

public:
  Grafo(int n) {
    // Inicializar la matriz de adyacencia
    matrizAdyacencia.resize(n, vector<int>(n, 0));

    // Inicializar la lista de adyacencia
    listaAdyacencia.resize(n);
  }

  void agregarConexion(int a, int b, int peso) {
    matrizAdyacencia[a][b] = peso;
    matrizAdyacencia[b][a] = peso;
    listaAdyacencia[a].push_back(b);
    listaAdyacencia[b].push_back(a);
    aristas.push_back(Arista(a, b, peso));
  }

  void imprimirMatrizAdyacencia() {
    for (int i = 0; i < matrizAdyacencia.size(); i++) {
      for (int j = 0; j < matrizAdyacencia[i].size(); j++) {
        cout << matrizAdyacencia[i][j] << " ";
      }
      cout << "\n";
    }
  }

  bool EstaEnSolucion(int v, vector<vertice> Solucion){
      for(int i=0; i<Solucion.size();i++){
        if(Solucion[i].first.second==v){
          return true;
        }
      }  
      return false;
  }

  void OrdenarCola(vector<vertice>& S){
    vertice temp;
    int i, j;
    for (i = 0; i < S.size(); i++) {
      for (j = i + 1; j < S.size(); j++) {
        if (S[i].first.first > S[j].first.first) {
          temp = S[i];
          S[i] = S[j];
          S[j] = temp;
        }
      }
    }
  }

  int EncontrarPlaza(int i,vector<vertice>& S){
    for(int j=0; j<S.size();j++){
        if(S[j].first.second==i){
          return j;
        }
      }  
  }

  vector<pair<pair<int,int>,int>> PrimPlazas(){
      vector<vertice> Plazas;
      vector<vertice> Solucion;
      vertice PlazaActual;
      int precio=0;

      for (int i=0; i<getVertices(); i++){
        vertice aux(pair<int,int>(precio,i),-1);
        Plazas.push_back(aux);
        precio=numeric_limits<int>::max();
      }

      while(!Plazas.empty()){
          PlazaActual=Plazas.front();
          swap(Plazas[0],Plazas[Plazas.size()-1]);
          Plazas.pop_back();
          Solucion.push_back(PlazaActual);
          

          for(int i=0; i<getVertices();i++){
            if(matrizAdyacencia[PlazaActual.first.second][i]>0){
              if(!EstaEnSolucion(i,Solucion) && (matrizAdyacencia[PlazaActual.first.second][i]<Plazas[EncontrarPlaza(i,Plazas)].first.first) ){
                Plazas[EncontrarPlaza(i,Plazas)].first.first=matrizAdyacencia[PlazaActual.first.second][i];
                Plazas[EncontrarPlaza(i,Plazas)].second=PlazaActual.first.second;
              }
              
            }
          }
          OrdenarCola(Plazas);
      }
    return Solucion;
  }

private:

  int getVertices(){
    return matrizAdyacencia.size();
  }
};

int main(){
    int n = 5; // Cantidad de nodos (plazas)
    Grafo ciudad(n);
    int suma=0;

    // Para la prueba, utilizaremos las calles y plazas de Algovilla del Tuerto.
    // Plaza Azcarate: Nodo 0
    // Plaza de la Libertad: Nodo 1
    // Plaza Mayor: 2
    // Plaza de las Maravilas: Nodo 3
    // Plaza de la Constitucion: Nodo 4

    ciudad.agregarConexion(0, 1, 1100000);
    ciudad.agregarConexion(0, 2, 130000);
    ciudad.agregarConexion(0, 3, 450004);
    ciudad.agregarConexion(0, 4, 748556);
    ciudad.agregarConexion(1, 2, 1300000);
    ciudad.agregarConexion(1, 3, 555123);
    ciudad.agregarConexion(1, 4, 1700000);
    ciudad.agregarConexion(2, 4, 554521);
    ciudad.agregarConexion(3, 4, 143552);

    vector<vertice> solucion = ciudad.PrimPlazas();

    for(int i=0; i<solucion.size();i++){
      cout << solucion[i].first.first << " " << solucion[i].first.second << " " << solucion[i].second << endl;
      suma+=solucion[i].first.first;
    }
    cout << "La suma total de realizar la reforma sería de: " << suma << endl;
  return 0;

}