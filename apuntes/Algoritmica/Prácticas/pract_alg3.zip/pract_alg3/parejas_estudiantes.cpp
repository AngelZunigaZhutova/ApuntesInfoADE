#include <vector>
#include <iostream>
#include <utility>
#include <cstdlib>
#include <list>

#define alumnos pair<int,int>
#define pareja pair<alumnos,int>



using namespace std;

list<pareja> Parejas(vector<vector<int>> estudiantes){
    vector<pareja> afinidad;
    list<pareja> solucion;
    for (int i = 0; i < estudiantes.size(); i++){
        for (int j = i; j < estudiantes.size(); j++){
            if (estudiantes[i][j] > 0)
            {
                afinidad.push_back(pair(pair(i, j), estudiantes[i][j] * estudiantes[j][i]));
            }
        }
    }

    while (!afinidad.empty()){
        int max = 0;
        for (int i = 0; i < afinidad.size(); i++){
            if (afinidad[max].second < afinidad[i].second){
                max = i;
            }
        }
        solucion.push_back(afinidad[max]);
        for (auto i = afinidad.begin(); i != afinidad.end(); ++i){
            if (i->first.first == solucion.back().first.first || i->first.second == solucion.back().first.second || i->first.second == solucion.back().first.first || i->first.first == solucion.back().first.second){
                i = afinidad.erase(i);
                --i;
            }
        }
    }
    return solucion;
}
int main(){
    int ent=0;
    vector<vector<int>> matr(6,vector<int>(6));

    //Implementación para valores aleatorios
    // srand(time(NULL));
    // for(int i=0; i < matr.size();i++){
    //     matr[i][i]=-1;
    // }
    // for(int i=0;i<matr.size();i++){
    //     for(int j=0; j<matr.size();j++){
    //         if(matr[i][j]>=0){
    //         ent=rand()%11;
    //         if(ent==0){
    //             ent++;
    //         }
    //         matr[i][j]=ent;
    //         }
    //     }
    // }
    
    matr[0][0]=1;matr[0][1]=8;matr[0][2]=2;matr[0][3]=7; matr[0][4]=1; matr[0][5]=3;
    matr[1][0]=8;matr[1][1]=1;matr[1][2]=6;matr[1][3]=2; matr[1][4]=9; matr[1][5]=2;
    matr[2][0]=2;matr[2][1]=6;matr[2][2]=1;matr[2][3]=9; matr[2][4]=2; matr[2][5]=8;
    matr[3][0]=7;matr[3][1]=2;matr[3][2]=4;matr[3][3]=1; matr[3][4]=5; matr[3][5]=9;
    matr[4][0]=1;matr[4][1]=9;matr[4][2]=2;matr[4][3]=5; matr[4][4]=1; matr[4][5]=4;
    matr[5][0]=3;matr[5][1]=2;matr[5][2]=8;matr[5][3]=9; matr[5][4]=4; matr[5][5]=1;
    

    cout << "Tabla de preferencia de estudiantes: " << endl;
    cout<<"   Alumno  ";
    int letra='A';
    for(int h=0;h<matr.size();h++){
        cout<<h+1<<" ";

    }
    cout<<endl;

    for(int i=0;i<matr.size();i++){

        cout<<"     "<<i+1<<"     ";
        for(int j=0; j<matr.size();j++){
            cout<<matr[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
    list<pareja>listafin=Parejas(matr);

    cout << "Las parejas mas optimas segun nuestro algoritmo son: " << endl;

    for(auto i=listafin.begin();i!=listafin.end();++i){
        cout<<"(" << i->first.first+1<<"," << i->first.second+1 << ") -> " << i->second << endl;
    }

}
