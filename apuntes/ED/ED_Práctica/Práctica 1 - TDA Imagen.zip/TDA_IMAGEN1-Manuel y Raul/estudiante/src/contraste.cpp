//
// Created by alumno on 19/10/23.
//
#include "image.h"
#include <cassert>
#include <iostream>
using namespace std;

int main(int argc, char * argv[]){
    char *ruta_orig, *ruta_dest; // nombres de los ficheros
    Image original;  //La llamaremos original para aclarar la función que estamos realizando y que va a pasar con la imagen. (Aun que al principio
//será la original no la ajustada).

// Comprobar validez de la llamada
    if(argc != 7){
        cerr << "Error: Numero incorrecto de parametros.\n";
        cerr << "Uso: negativo <FichImagenOriginal> <FichImagenDestino>\n";
        exit (1);
    }

// Obtener argumentos
    ruta_orig  = argv[1];
    ruta_dest = argv[2];

// Mostramos argumentos
    cout << endl;
    cout << "Fichero origen: " << ruta_orig << endl;
    cout << "Fichero resultado: " << ruta_dest << endl;

// Leer la imagen del fichero de entrada, si da fallo avisamos y cerramos
    if (!original.Load(ruta_orig)){
        cerr << "Error: No pudo leerse la imagen." << endl;
        cerr << "Terminando la ejecucion del programa." << endl;
        return 1;
    }

    int e1=atoi(argv[3]), e2=atoi(argv[4]), s1=atoi(argv[5]), s2=atoi(argv[6]); //Pasamos parámetros de *char a enteros   //e1-->entrada1   s1-->salida1 (mismo que in y out, pero en español)

// Mostrar los parametros de la Imagen
    cout << endl;
    cout << "Dimensiones de " << ruta_orig << ":" << endl;
    cout << "   Imagen   = " <<  original.get_rows() << " filas x " << original.get_cols() << " columnas " << endl;

// Creamos la imagen icono a partir de nuestra imagen original que llama a la función Subsample(int)
    original.AdjustContrast(e1,e2,s1,s2);

// Guardar la imagen resultado en el fichero, y sino se guarda dar mensaje de error
    if (original.Save(ruta_dest))
        cout  << "La imagen se guardo en " << ruta_dest << endl;
    else{
        cerr << "Error: No pudo guardarse la imagen." << endl;
        cerr << "Terminando la ejecucion del programa." << endl;
        return 1;
    }
    return 0;
}