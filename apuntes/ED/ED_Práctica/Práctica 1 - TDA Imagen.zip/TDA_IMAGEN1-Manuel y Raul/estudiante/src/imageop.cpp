/**
 * @file imageop.cpp
 * @brief Fichero con definiciones para el resto de métodos de la clase Image
 */

#include <iostream>
#include <cmath>
#include <image.h>

#include <cassert>
#include <ctime>


void Image::Invert(){
    /* En este principal cálculo se basaría nuestra función invert para sacar el negativo de una imagen, el cual se encuentra en negativo.cpp
    for (int i=0; i<image.size(); i++)
        image.set_pixel(i,255-image.get_pixel(i));
    */
    for (int i=0; i<this->size(); i++) {
        this->set_pixel(i, 255 - this->get_pixel(i));  //Se resta a 255 el valor del pixel actual, formando asi el negativo de la fotografia actual.
    }

}


void Image::AdjustContrast(byte in1, byte in2, byte out1, byte out2) {  // old_min=in1 (a) old_max=in2 (b)  new_min=out1 (min) new_max=out2 (max)
    double primer_tramo = 1.0*out1/in1;                     // Ya arriba hemos asociado cada letra de la fórmula expuesta en la explicación de la práctica con
    double segundo_tramo = 1.0*(out2-out1)/(in2-in1);       // cada uno de los parámetros que obtenemos.
    double tercer_tramo = 1.0*(255-out2)/(255-in2);
                                                            //Importante prestar atención a la gráfica que la práctica en el apartado de contraste.cpp para poder ver esos "tres cachos" de la función.
    for(int k = 0; k < size(); k++) {
        if (get_pixel(k) < in1)     // duda
            set_pixel(k, round(primer_tramo * get_pixel(k)));
        else if (get_pixel(k) <= in2)
            set_pixel(k, round(out1 + segundo_tramo * (get_pixel(k) - in1)));
        else if (get_pixel(k) <= 255)
            set_pixel(k, round(out2 + tercer_tramo * (get_pixel(k) - in2)));
    }
}


double Image::Mean(int i, int j, int height, int width) const {
    double suma=0,cant_pix=height*width;
    if(height >0 && width>0){
        for(int f=0;f<height;f++){
            for(int c=0;c<width;c++){
                suma+=get_pixel(f+i,c+j);
            }
        }
    }
    return  suma/cant_pix;     //Si altura o amplitud tienen valor diferente de cero o mayor de cero, la función devolverá 0, ya que al no entrar en if, valor de double suma=0. (0/n=0)
}


Image Image::Subsample(int factor) const{
    Image icono;
    if(factor>0) {
        int newf = get_rows() / factor, newc = get_cols() / factor;
        Image iconotrue(newf,
                        newc);      //Seteamos en iconotrue el nuevo número de rows y cols que tendrá nuestro icono
        icono = iconotrue;                             //Igualamos icono a iconotrue
        for (int f = 0; f < newf; f++) {
            for (int c = 0; c < newc; c++) {
                byte value_byte = round(Mean(f * factor, c * factor, factor,
                                             factor)); //En esta parte hacemos que cada factor*factor byte de la imagen original se
                icono.set_pixel(f, c,value_byte);                                         // conviertan en uno solo mediante dos bucles que juegan la posición, creando así
            }                                                                                       // nuestro icono (el método parece especialmente pensado para que factor tenga valor 2).
        }
    }
    return icono;     //Si factor es menor o igual que cero, devolverá una imagen vacía; devolvemos icono
}


Image Image::Crop(int nrow, int ncol, int height, int width) const {
    assert(nrow>=0 && ncol>=0); //@precondition: parameters>=0
    Image recorte(height,width);
        for(int f=0; f<height; f++){
            for(int c=0; c<width; c++){
                recorte.set_pixel(f,c, get_pixel(f+nrow,c+ncol));    //Formamos nueva imagen a partir de las row y col pasadas como parámetro.
            }
        }
    return recorte;
}


Image Image::Zoom2X() const{
    int oldf=this->get_rows(), oldc=this->get_cols(), newf=2*(this->get_rows())-1, newc=(2*this->get_cols())-1;
    Image aumentada=Image(newf,newc); //Creamos nueva imagen con el nrows y ncol que va a tener.

    // Ponemos las tres primeras columnas sobre las que vamos a interpolar en sus respectivos huecos.
    for(int f=0;f<oldf;f++){
        for(int c=0;c<oldc;c++){
                aumentada.set_pixel(f*2,c*2,this->get_pixel(f,c));//Pone las filas y columnas de la imagen original en la nueva imagen final

        }
    }
    // Rellenamos las columnas vacías entre nuestras columnas antiguas (interpolamos sobre columnas)
    for(int f=0; f< aumentada.get_rows(); f+=2){
        for(int c=1; c<aumentada.get_cols(); c+=2){
            double media=(aumentada.get_pixel(f,c-1) + aumentada.get_pixel(f,c+1))/2.0;
            aumentada.set_pixel(f,c,round(media));
        }
    }

    //Ahora una vez tenemos los dos primeros pasos, ahora rellenamos los huecos restantes interpolando sobre filas, y recurriremos a un criterio
    // de paridad para ello.
    for(int f=1; f<aumentada.get_rows(); f+=2){
        for(int c=0; c<aumentada.get_cols(); c++){
            if(c%2 == 0) {//Toma valor medio de sus dos vecinos.
                aumentada.set_pixel(f, c, round((aumentada.get_pixel(f - 1, c) + aumentada.get_pixel(f + 1, c)) / 2.0));
            }
            else { //Toma valor medio de valor medio de los 4 vecinos de sus diagonales.
                aumentada.set_pixel(f, c, round((aumentada.get_pixel(f - 1, c - 1) + aumentada.get_pixel(f - 1, c + 1) +
                                                 aumentada.get_pixel(f + 1, c - 1) +
                                                 aumentada.get_pixel(f + 1, c + 1)) / 4.0));
            }
        }
    }
    return aumentada;  //Finalmente devuelve nuestra imagen aumentada.
}


void Image::ShuffleRows() {      // Este es el Shufflerows primerizo, el que viene ya hecho y no hay que implementar.
    const int coprimo = 9973;
    Image temp(rows,cols);
    int newr;
    for (int r=0; r<rows; r++){
        newr = r*coprimo % rows;
        for (int c=0; c<cols;c++)
            temp.set_pixel(r,c,get_pixel(newr,c));
        }
    Copy(temp);
}


void Image::NewShuffleRows(){   //El nuevo ShuffleRows que nos piden implementar, por eso hemos decidido llamarlo NewShuffleRows

    const int p = 9973;
    byte **aux = new byte * [rows];
    // Primero realizamos la copia
    for (int r=0; r<rows; r++) aux[r] = img[r];
    for(int r=0; r<rows; r++){
        int newr = r*p%rows;
        img[r] = aux[newr];
    }

    delete [] aux;
    aux = nullptr;
    /*const int coprimo=9973;
    //int nr=this->rows;
    byte **aux_image = new byte * [rows];
    for(int r=0; r<rows; r++){
        aux_image[r]= img[r];
    }
    for(int r=0; r<rows; r++){
        int newr = r*coprimo%rows;
        img[r] = aux_image[newr];
    }
    delete [] aux_image;
    aux_image=nullptr; //aux_image=0;
     */

}
