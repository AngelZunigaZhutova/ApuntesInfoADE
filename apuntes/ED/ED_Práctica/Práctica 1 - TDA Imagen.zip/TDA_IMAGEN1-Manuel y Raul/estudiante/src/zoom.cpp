//
// Created by alumno on 20/10/23.
//
#include "image.h"
#include <cassert>
#include <iostream>
using namespace std;

int main(int argc, char * argv[]){
  char *ruta_orig, *ruta_dest; // nombres de los ficheros
  Image original;  //La llamaremos aumentada para aclarar la función que estamos realizando y que va a pasar con la imagen. (Aun que al principio
                    //será la original no la aumentada).

  // Comprobar validez de la llamada
  if(argc != 6){
      cerr << "Error: Numero incorrecto de parametros.\n";
    cerr << "Uso: negativo <FichImagenOriginal> <FichImagenDestino>\n";
    exit (1);
    }

  // Obtener argumentos
  ruta_orig  = argv[1];
  ruta_dest = argv[2];

  // Mostramos argumentos
  cout << endl;
  cout << "Fichero origen: " << ruta_orig << endl;
  cout << "Fichero resultado: " << ruta_dest << endl;

  // Leer la imagen del fichero de entrada, si da fallo avisamos y cerramos
    if (!original.Load(ruta_orig)){
        cerr << "Error: No pudo leerse la imagen." << endl;
        cerr << "Terminando la ejecucion del programa." << endl;
        return 1;
    }

    int row=atoi(argv[3]), col=atoi(argv[4]), lado=atoi(argv[5]); //Pasamos parámetros de *char a enteros

  // Mostrar los parametros de la Imagen
  cout << endl;
  cout << "Dimensiones de " << ruta_orig << ":" << endl;
  cout << "   Imagen   = " <<  original.get_rows() << " filas x " << original.get_cols() << " columnas " << endl;

  // Aquí es donde realmente conseguimos la imagen aumentada (primero hacemos crop para cortar imagen, y luego zoom sobre este recorte para conseguir la funcion)
  Image recorte(original.Crop(row,col,lado,lado));
  Image aumentada(recorte.Zoom2X());

  // Guardar la imagen resultado en el fichero, y sino se guarda dar mensaje de error
    if (aumentada.Save(ruta_dest))
        cout  << "La imagen se guardo en " << ruta_dest << endl;
    else{
        cerr << "Error: No pudo guardarse la imagen." << endl;
        cerr << "Terminando la ejecucion del programa." << endl;
        return 1;
    }
  return 0;
}

