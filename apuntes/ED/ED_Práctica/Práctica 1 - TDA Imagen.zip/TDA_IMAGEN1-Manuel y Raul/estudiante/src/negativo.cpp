// Fichero: negativo.cpp
// Calcula el negativo de una imagen PGM
//

#include <iostream>
#include <cstring>
#include <cstdlib>

#include <image.h>
using namespace std;

int main (int argc, char *argv[]){
  char *ruta_orig, *ruta_dest; // nombres de los ficheros
  Image invertida;  //La llamaremos invertida para aclarar la función que estamos realizando y que va a pasar con la imagen.(aunque esta imagen
                    // aún no esté invertida.

  // Comprobar validez de la llamada
  if(argc != 3){
      cerr << "Error: Numero incorrecto de parametros.\n";
    cerr << "Uso: negativo <FichImagenOriginal> <FichImagenDestino>\n";
    exit (1);
    }

  // Obtener argumentos
  ruta_orig  = argv[1];
  ruta_dest = argv[2];

  // Mostramos argumentos
  cout << endl;
  cout << "Fichero origen: " << ruta_orig << endl;
  cout << "Fichero resultado: " << ruta_dest << endl;

  // Leer la imagen del fichero de entrada, si da fallo avisamos y cerramos
    if (!invertida.Load(ruta_orig)){
        cerr << "Error: No pudo leerse la imagen." << endl;
        cerr << "Terminando la ejecucion del programa." << endl;
        return 1;
    }

  // Mostrar los parametros de la Imagen
  cout << endl;
  cout << "Dimensiones de " << ruta_orig << ":" << endl;
  cout << "   Imagen   = " <<  invertida.get_rows() << " filas x " << invertida.get_cols() << " columnas " << endl;

  // Calcular el negativo de nuestra imagen
  invertida.Invert();

  // Guardar la imagen resultado en el fichero, y sino se guarda dar mensaje de error
    if (invertida.Save(ruta_dest))
        cout  << "La imagen se guardo en " << ruta_dest << endl;
    else{
        cerr << "Error: No pudo guardarse la imagen." << endl;
        cerr << "Terminando la ejecucion del programa." << endl;
        return 1;
    }
  return 0;
}
