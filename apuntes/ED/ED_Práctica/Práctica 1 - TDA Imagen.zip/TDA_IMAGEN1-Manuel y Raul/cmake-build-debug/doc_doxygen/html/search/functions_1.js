var searchData=
[
  ['crop_40',['Crop',['../classImage.html#aad309b582d08dfd826c5106eaf80eb1e',1,'Image']]]
];
