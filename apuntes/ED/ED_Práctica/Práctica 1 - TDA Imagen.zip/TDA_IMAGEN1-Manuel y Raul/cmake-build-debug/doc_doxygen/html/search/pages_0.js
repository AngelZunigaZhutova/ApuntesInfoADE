var searchData=
[
  ['documentación_20de_20práctica_3a_20tda_20imagen_2e_62',['Documentación de Práctica: TDA imagen.',['../index.html',1,'']]]
];
