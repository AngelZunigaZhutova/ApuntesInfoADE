var searchData=
[
  ['estudio_20de_20eficiencia_3a_20shufflerows_28_29_63',['Estudio de eficiencia: ShuffleRows()',['../eficiencia.html',1,'']]]
];
