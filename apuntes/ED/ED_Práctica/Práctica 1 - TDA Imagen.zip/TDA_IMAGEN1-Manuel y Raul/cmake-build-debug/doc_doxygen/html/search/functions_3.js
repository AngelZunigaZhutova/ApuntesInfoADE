var searchData=
[
  ['get_5fcols_42',['get_cols',['../classImage.html#ac52444a5ffbbc50d6dde8375ca5f45ea',1,'Image']]],
  ['get_5fpixel_43',['get_pixel',['../classImage.html#aca8a815018d91548953cf571d778020e',1,'Image::get_pixel(int i, int j) const'],['../classImage.html#af844c47ac8a352b0e503e48a7af7ee35',1,'Image::get_pixel(int k) const']]],
  ['get_5frows_44',['get_rows',['../classImage.html#a19fc606085e6e76dedf57b7de391dfdb',1,'Image']]]
];
