/**
 * @file letters_set.cpp
 * @brief Archivo de implementación del TDA LettersSet
 * @authors Raúl Martínez Bustos, Manuel Marín Rodríguez
 * @date diciembre 2023
 */

#include "letters_set.h"

LettersSet::LettersSet(){
    clear();
}

LettersSet::LettersSet(const LettersSet & otro){
    letters = otro.letters;
}

bool LettersSet::insert(const pair<char,LetterInfo> & x){
    return letters.insert(x).second;
}

bool LettersSet::erase(const char & x){
    return letters.erase(x);
}

void LettersSet::clear(){
    letters.clear();
}

bool LettersSet::empty() const{
    return letters.empty();
}

unsigned int LettersSet::size() const{
    return letters.size();
}

int LettersSet::getScore(string x){
    int score = 0;
    for(int i = 0; i < x.length(); i++) score+=letters.find(toupper(x.at(i)))->second.score;
    return score;
}

LettersSet & LettersSet::operator=(const LettersSet & x){
    if(&x != this) letters = x.letters;
    return *this;
}

LetterInfo & LettersSet::operator[](const char & x){
    return letters[x];
}

ostream & operator <<(ostream & os, const LettersSet & x){
    cout << "Letra " << "Cantidad " << "Puntos";
    map<char,LetterInfo>::const_iterator it;
    for(it = x.letters.begin(); it != x.letters.end(); ++it) {
        cout << it->first << "\t" << it->second.repetitions  << "\t" << it->second.score;
        cout << endl;
    }
    return os;
}

istream & operator >>(istream & is, LettersSet & x){
    string text;
    getline(is,text);
    LetterInfo aux;
    char l;
    while(is){
        is >> l;
        is >> aux.repetitions;
        is >> aux.score;
        pair<char,LetterInfo> pair(l,aux);
        x.insert(pair);
    }
    return is;
}