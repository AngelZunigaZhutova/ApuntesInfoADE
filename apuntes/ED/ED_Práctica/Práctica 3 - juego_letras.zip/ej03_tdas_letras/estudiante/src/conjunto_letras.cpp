/**
 * @file conjunto_letras.cpp
 * @brief Prueba el funcionamiento del TDA LettersSet
 * @authors Raúl Martínez Bustos, Manuel Marín Rodríguez
 * @date diciembre 2023
 */

#include "letters_set.h"
#include <fstream>

int main(int argc, char* argv[]){

    //DECLARACIÓN
    LettersSet l;
    ifstream en;
    en.open(argv[1]);

    if(!en.is_open()){
        cout << "Error abriendo el fichero" << argv[1] << endl;
        cerr << "Error en ola función llamada pen()" << endl;
        return -1;
    }
    en >> l;
    en.close();
    int score = l.getScore(argv[2]);

    //SALIDA
    cout << score << endl;
    return 0;
}