/**
 * @file cantidad_letras.cpp
 * @brief Prueba el funcionamiento del TDA Dictionary
 * @authors ARaúl Martínez Bustos, Manuel Marín Rodríguez
 * @date diciembre 2023
 */

#include "dictionary.h"
#include "letters_set.h"
#include<fstream>

int main(int argc, char* argv[]){
    //DECLARACIÓN
    Dictionary dic;
    ifstream en;
    en.open(argv[1]);
    string x;

    //ABRIENDO ARCHIVOS
    if(!en.is_open()){
        cout << "Error abriendo el fichero" << argv[1] << endl;
        cerr << "Error en la función llamada open()" << endl;
        return -1;
    }
    while(en){
        en >> x;
        dic.insert(x);
    }

    en.close();
    LettersSet letters;
    ifstream entrada1;
    entrada1.open(argv[2]);
    entrada1 >> letters;
    entrada1.close();

    //SALIDA
    char l = 'A';
    int total = dic.getTotalLetters();
    cout << "Letra\tFAbs.\tFrel." << "\n";
    while(l <= 'Z'){
        if(letters[l].repetitions != 0) {
            int ocurrences = dic.getOcurrences(l);
            cout << l << "\t" << ocurrences << "\t" << (double)ocurrences/total << "\n";
        }
        l++;
    }

    return 0;
}