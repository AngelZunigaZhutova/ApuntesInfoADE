/**
 * @file bolsa_letras.cpp
 * @brief Prueba el funcionamiento del TDA LettersBag
 * @authors Raúl Martínez Bustos, Manuel Marín Rodríguez
 * @date diciembre 2023
 */

#include "letters_bag.h"
#include<fstream>

int main(int argc, char** argv){

    LettersSet let;
    ifstream en;
    en.open(argv[1]);

    if(!en.is_open()){
        cout << "Error abriendo el fichero" << argv[1] << endl;
        cerr << "Error en la función llamada open()" << endl;
        return -1;
    }
    en >> let;
    en.close();
    LettersBag letterbag(let);
    while(letterbag.size() != 0) cout << letterbag.extractLetter() << endl;

    return 0;
}