/**
 * @file letters_bag.cpp
 * @brief Archivo de implementación del TDA LettersBag
 * @authors Raúl Martínez Bustos, Manuel Marín Rodríguez
 * @date diciembre 2023
 */

#include "letters_bag.h"

LettersBag::LettersBag(const LettersSet & x){
    LettersSet aux = x;
    char l = 'A';
    while(l <= 'Z'){
        for(int i = 0; i < aux[l].repetitions; i++) letters.add(l);
        l+=1;
    }

}

void LettersBag::insertLetter(const char & x){
    letters.add(x);
}

char LettersBag::extractLetter(){
    return letters.get();
}

vector<char> LettersBag::extractLetters(int x){
    vector<char> aux;
    for(int i = 0; i < x; i++) aux.push_back(extractLetter());
    return aux;
}

void LettersBag::clear(){
    letters.clear();
}

unsigned int LettersBag::size() const{
    return letters.size();
}

LettersBag & LettersBag::operator=(const LettersBag & otro){
    if(&otro != this) letters = otro.letters;
    return *this;
}