/**
 * @file letters_bag.h
 * @brief Archivo de especificación del TDA LettersBag
 * @authors Raúl Martínez Bustos, Manuel Marín Rodríguez
 * @date diciembre 2023
 */

#include "letters_set.h"
#include "bag.h"

#ifndef __LETTERS_BAG_H__
#define __LETTERS_BAG_H__

/**
 * @brief TDA LettersBag
 *
 * Este TDA almacena un conjunto de chars utilizado en el juego de letras.
 * La estructura de datos subyacente es una lista de chars.
 */

class LettersBag {
private:
    Bag <char> letters;
public:

    /**
     * @brief Constructor a partir de un LettersSet
     * @param x TEl LettersSet en cuestión
     */
    LettersBag(const LettersSet & x);

    /**
     * @brief Introduce una letra
     * @param x letra a meter
     * @post La bolsa de letras la añade al final
     */
    void insertLetter(const char & x);

    /**
     * @brief Extrae una letra aleatoriamente y la borra
     * @return char de la letra
     * @post La bolsa de letras pierde esa letra
     */
    char extractLetter();

    /**
     * @brief Extrae un conjunto de letras y las borra
     * @param num Número de letras
     * @return Lista con las letras extraídas
     * @post La bolsa de letras pierde estas
     */
    vector<char> extractLetters(int num);

    /**
     * @brief Vacía la LettersBag
     * Elimina todo lo existente
     * @post La LettersBag se vacía
     */
    void clear();

    /**
     * @brief Tamaño de la bolsa
     * @return int con el tamaño
     */
    unsigned int size() const;

    /**
     * @brief Sobrecarga del operador de asignación
     * @param otro LettersBag a copiar
     * @return Referencia a this
     * */
    LettersBag & operator=(const LettersBag & otro);


};

#endif