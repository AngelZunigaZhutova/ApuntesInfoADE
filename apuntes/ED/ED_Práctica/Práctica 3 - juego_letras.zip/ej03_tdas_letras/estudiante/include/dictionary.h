/**
 * @file dictionary.h
 * @brief Archivo de especificación del TDA Dictionary
 * @authors Raúl Martínez Bustos, Manuel Marín Rodríguez
 * @date diciembre 2023
 */

#include<iostream>
#include <vector>
#include<set>

using namespace std;

#ifndef __DICTIONARY_H__
#define __DICTIONARY_H__

/**
 * @brief TDA Dictionary
 * @details Almacena las palabras de un fichero de texto y permite iterar sobre ellas
 */

class Dictionary {
private:
    set <string> words;
public:

    /**
     * @brief Constructor
     * Crea un Dictionary
     */
    Dictionary();

    /**
     * @brief Constructor de copia
     * Crea un Dictionary igual al otro
     * @param otro Dictionary a copiar
     */
    Dictionary(const Dictionary & otro);

    /**
     * @brief Indica si una palabra está
     * @param x la palabra en cuestión
     * @return Bool que dice si existe o no
     */
    bool exists(const string & x) const;

    /**
     * @brief Inserta una palabra
     * @param x palabra a insertar
     * @return Bool que indica si esa palabra no existía y se crea
     */
    bool insert(const string & x);

    /**
     * @brief Elimina una palabra
     * @param x Palabra a borrar
     * @return Bool que dice si se ha borrado
     */
    bool erase(const string & x);

    /**
     * @brief Limpia el Dictionary
     * Elimina todas las palabras
     * @post El diccionario no tiene nada
     */
    void clear();

    /**
     * @brief Comprueba si el diccionario está vacío
     * @return true si lo está, false sino
     */
    bool empty() const;

    /**
     * @brief Tamaño del diccionario
     * @return Número de palabras que tiene
     */
    unsigned int size() const;

    /**
     * @brief Indica el número de veces que aparece una letra
     * @param x letra en cuestión
     * @return La cantidad de esta
     */
    int getOcurrences(const char x);

    /**
     * @brief Número total de letras
     * @return Entero con el total
     */
    int getTotalLetters();

    /**
     * @brief Devuelve las palabras con esa longitud
     * @param lon Longitud en cuestión
     * @return Vector de palabras con esa longitud
     */
    vector<string> wordsOfLength(int lon);

    /**
     * @brief TDA iterator de Dictionary
     * Permite recorrer el Dictionary
     */
    class iterator{
    private:
        set<string>::iterator it;

    public:

        /**
         * @brief Constructor sin parámetros
         */
        iterator(){}

        /**
         * @brief Constructor de copia
         * @param otro iterador sobre un set de datos para copiar
         */
        iterator(const set<string>::iterator& otro):it(otro){}

        /**
         * @brief Constructor de copia
         * @param otro iterador para copiar
         * @post El objeto implícito es igual a otro
         */
        iterator(const iterator& otro):it(otro.it){}
        /**
         * @brief Destructor
         */
        ~iterator(){}

        /**
         * @brief Operador de asignación
         * @param otro iterador sobre un set de datos string a copiar
         * @return puntero al objeto implícito
         */
        iterator& operator=(const set<string>::iterator& otro){it=otro;return *this;}
        /**
         * @brief Operador de asignación
         * @param otro iterador a copiar
         * @return puntero al objeto implícito
         */
        iterator& operator=(const iterator& otro){it=otro.it;return *this;}
        /**
         * @brief Obtiene el objeto al que apunta el iterador.
         * @pre El objeto implícito es distinto de end()
         * @return Elemento del diccionario al que apunta el iterador
         */
        string operator*()const{return *it;}
        /**
         * @brief Operador de preincremento
         * @pre El objeto implícito es distinto a end()
         * @return puntero al objeto implícito
         * @post El iterador apunta una posición más a la derecha
         */
        iterator& operator++(){++it;return *this;}
        /**
         * @brief Operador de predecremento
         * @pre El objeto implícito es distinto a begin()
         * @return puntero al objeto implícito
         * @post El iterador apunta una posición más a la izquierda
         */
        iterator& operator--(){--it;return *this;}
        /**
         * @brief Operador de postincremento
         * @pre El objeto implícito es distinto a end()
         * @return puntero al objeto implícito
         * @post El iterador apunta una posición más a la derecha
         */        iterator& operator++(int){it++;return *this;}
        /**
          * @brief Operador de postdecremento
          * @pre El objeto implícito es distinto a begin()
          * @return puntero al objeto implícito
          * @post El iterador apunta una posición más a la izquierda
          */
        iterator& operator--(int){it--;return *this;}
        /**
         * @brief Operador de desigualdad
         * @param otro iterador con el que se va a comparar el objeto implícito
         * @return FALSE si apuntan a la misma posición y TRUE si no es así
         */
        bool operator!=(const iterator& otro){return it != otro.it;}
        /**
         * @brief Operador de igualdad
         * @param otro iterador con el que se va a comparar el objeto implícito
         * @return TRUE si apuntan a la misma posición y FALSE si no es así
         */
        bool operator==(const iterator& otro){return it == otro.it;}
    };

    /**
     * @brief Devuelve un iterador que apunta al comienzo del diccionario
     * @return iterador apuntando al principio del set words
     */
    iterator begin(){iterator i = words.begin();return i;}

    /**
     * @brief Devuelve un iterador que apunta al final del diccionario (posición después de la última)
     * @return iterador apuntando al final del set words
     */
    iterator end(){iterator i = words.end();return i;}

    /**
     * @brief TDA const_iterator asociado a Dictionary, señala a los elementos contenidos en él.
     *
     *
     * Permite recorrer el Dictionary pero no modificarlo, por lo que se puede usar tanto con
     * Dictionary constantes como no constantes.
     * Es mutable.
     */
    class const_iterator{
    private:
        set<string>::const_iterator it;

    public:

        /**
         * @brief Constructor sin parámetros
         */
        const_iterator(){}
        /**
         * @brief Constructor de copia
         * @param otro
         */
        const_iterator(const set<string>::const_iterator& otro):it(otro){}
        /**
         * @brief Constructor de copia
         * @param otro
         */
        const_iterator(const const_iterator& otro):it(otro.it){}
        /**
         * @brief Destructor
         */
        ~const_iterator(){}
        /**
         * @brief Operador de asignación
         * @param otro iterador constante al que se va a igualar el implícito
         * @return puntero al objeto implícito
         */
        const_iterator& operator=(const set<string>::const_iterator& otro){it=otro;return *this;}
        /**
         * @brief Operador de asignación
         * @param otro iterador constante al que se va a igualar el implícito
         * @return puntero al objeto implícito
         */
        const_iterator& operator=(const const_iterator& otro){it=otro.it;return *this;}
        /**
         * @brief Obtiene el objeto al que apunta el iterador.
         * @pre El objeto implícito es distinto de end()
         * @return Elemento del diccionario al que apunta el iterador
         */
        const string operator*()const{return *it;}
        /**
         * @brief Operador de preincremento
         * @pre El objeto implícito es distinto a end()
         * @return puntero al objeto implícito
         * @post El iterador apunta una posición más a la derecha
         */
        const_iterator& operator++(){++it;return *this;}
        /**
         * @brief Operador de predecremento
         * @pre El objeto implícito es distinto a begin()
         * @return puntero al objeto implícito
         * @post El iterador apunta una posición más a la izquierda
         */
        const_iterator& operator--(){--it;return *this;}
        /**
         * @brief Operador de postincremento
         * @pre El objeto implícito es distinto a end()
         * @return puntero al objeto implícito
         * @post El iterador apunta una posición más a la derecha
         */
        const_iterator& operator++(int){it++;return *this;}
        /**
         * @brief Operador de postdecremento
         * @pre El objeto implícito es distinto a begin()
         * @return puntero al objeto implícito
         * @post El iterador apunta una posición más a la izquierda
         */
        const_iterator& operator--(int){it--;return *this;}
        /**
          * @brief Operador de desigualdad
          * @param otro iterador constante con el que se va a comparar el objeto implícito
          * @return FALSE si apuntan a la misma posición y TRUE si no es así
          */
        bool operator!=(const const_iterator& otro){return it != otro.it;}
        /**
         * @brief Operador de igualdad
         * @param otro iterador constante con el que se va a comparar el objeto implícito
         * @return TRUE si apuntan a la misma posición y FALSE si no es así
         */
        bool operator==(const const_iterator& otro){return it == otro.it;}
    };

    /**
     * @brief Devuelve un iterador constante que apunta al comienzo del diccionario
     * @return iterador constante apuntando al principio del set words
     */
    const_iterator begin() const{const_iterator i = words.begin();return i;}

    /**
     * @brief Devuelve un iterador constante que apunta al final del diccionario (posición después de la última)
     * @return iterador constante apuntando al final del set words
     */
    const_iterator end() const{const_iterator i = words.end();return i;}
};

#endif