/**
 * @file letters_set.h
 * @brief Archivo de especificación del TDA LettersSet
 * @authors Raúl Martínez Bustos, Manuel Marín Rodríguez
 * @date diciembre 2023
 */

#include<iostream>
#include<tuple>
#include<map>
#include<string>
using namespace std;

#ifndef __LETTER_SET_H__
#define __LETTER_SET_H__

/**
 * @brief TDA LetterInfo
 *
 * Contiene información sobre un determinado carácter del juego de las
 * letras. En concreto, almacena información sobre el número de repeticiones de
 * la letra en la partida y de la puntuación que otorga al utilizarse en una
 * palabra
 */

struct LetterInfo {
    int repetitions;
    int score;
};

/**
 * @brief TDA LettersSet
 *
 * Este TDA representa un conjunto de letras, con la información necesaria para
 * jugar una partida al juego de las letras, es decir, el número de repeticiones
 * que tenemos de la letra y la puntuación que dicha letra otorga cuando se
 * utiliza en una palabra
 */

class LettersSet{

private:

    map <char,LetterInfo> letters;
public:

    /**
     * @brief Constructor por defecto
     * Crea un LettersSet
     */
    LettersSet();

    /**
     * @brief Constructor de copia
     * @param otro LettersSet que se copia
     */
    LettersSet(const LettersSet & otro);

    /**
     * @brief Inserta un elemento
     * @param x Letra y LetterInfo a introducir
     * @return Bool que dice si se ha metido correctamente
     */
    bool insert(const pair<char,LetterInfo> & x);

    /**
     * @brief Elimina un elemento
     * @param x Carácter en cuestión
     * @return Bool que dice si se ha eliminado correctamente
     */
    bool erase(const char & x);

    /**
     * @brief Limpia el contenido
     * @post Los elementos del LettersSet se borran
     */
    void clear();

    /**
     * @brief Consulta si el LettersSet tiene algo
     * @return true si el LettersSet está vacío, falso sino
     */
    bool empty() const;

    /**
     * @brief Tamaño del LettersSet
     * @return Número de elementos
     */
    unsigned int size() const;

    /**
     * @brief Calcula la puntuación de una palabra
     * @param x String de la palabra
     * @return Puntuación de la palabra, sumando sus letras
     */
    int getScore(string x);

    /**
     * @brief Sobrecarga del operador de asignación
     * @param x LettersSet a copiar
     * @return Referencia al objeto this
     */
    LettersSet & operator=(const LettersSet & x);

    /**
     * @brief Sobrecarga del operador de consulta
     * @param x Carácter a consultar
     * @return Estructura de tipo LetterInfo con la información del carácter
     */
    LetterInfo & operator[](const char & x);

    /**
     * @brief Sobrecarga del operador de salida
     * @param os Flujo de salida, donde escribir el LettersSet
     * @param x LettersSet que se escribe
     */
    friend ostream & operator <<(ostream & os, const LettersSet & x);

    /**
     * @brief Sobrecarga del operador de entrada
     * @param is Flujo de entrada, del que leer el LettersSet
     * @param x LettersSet en el que almacenar la información leída
     */

    friend istream & operator >>(istream & is, LettersSet & x);
};

ostream & operator <<(ostream & os, const LettersSet & cl);

istream & operator >>(istream & is, LettersSet & cl);

#endif