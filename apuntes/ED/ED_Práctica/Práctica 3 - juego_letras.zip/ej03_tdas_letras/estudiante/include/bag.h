/**
 * @file bag.h
 * @brief Archivo de especificación e implementación del TDA Bag
 * @authors Raúl Martínez Bustos, Manuel Marín Rodríguez
 * @date diciembre 2023
 */

#include<iostream>
#include<vector>
#include<string>
using namespace std;

#ifndef __BAG_H__
#define __BAG_H__

/**
 *  @brief TDA abstracto Bag
 *  Este TDA abstracto nos permite trabajar con una colección de elementos que
 *  permite la extracción de elementos de forma aleatoria sin reemplazamiento
 */

template <class T>
class Bag {

private:
    vector<T> v;
public:

    /**
     * @brief Constructor por defecto
     * Crea un onjeto Bag
     */
    Bag(){clear();}

    /**
     * @brief Constructor de copia
     * Crea una copia de el otro
     * @param otro Objeto que se copia
     */
    Bag(const Bag<T> & otro){
        this = otro;
    }

    /**
     * @brief Añade un elemento
     * @param x elemento a añadir
     * @post La bolsa añade el nuevo elemento
     */
    void add(const T & x) {
        v.push_back(x);
    }

    /**
     * @brief Extrae un elemento aleatoriamente (debe haber al menos uno)
     * Devuelve un elemento y lo borra
     * @return Elemento extraído
     * @post El elemento devuelto ya no está
     */
    T get(){
        srand(time(NULL));
        int pos = rand()%size();
        T result = v.at(pos);
        v.at(pos) = v.back();
        v.pop_back();
        return result;
    }

    /**
     * @brief Limpia la bolsa
     * Borra todos los elementos
     * @post La bolsa se vacía
     */
    void clear(){
        v.clear();
    }

    /**
     * @brief Tamaño
     * @return Número de elementos existentes
     */
    unsigned int size() const{
        return v.size();
    }

    /**
     * @brief Comprueba si la bolsa está vacía
     * @return true si la bolsa está vacía, falso si no lo está
     */
    bool empty(){
        return v.empty();
    }

    /**
     * @brief Sobrecarga del operador de asignación
     * @param otro Elemento a copiar
     * @return La referencia (this)
     */

    const Bag<T> & operator=(const Bag<T> & otro){
        if(&otro!=this) v = otro.v;
        return *this;
    }

};

#endif