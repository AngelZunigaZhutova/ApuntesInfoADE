/**
* @file maxqueue.h
* @brief  Funciones de la cola
* @authors Raúl Martínez Bustos y Manuel Marín Rodriguez
*/

#include <iostream>
#include <stack>

using namespace std;

struct dato {
    int valor = 0;
    int maximo = 0;
};

/**
 * @brief T.D.A MaxQueue
 * @authors Raúl Martínez Bustos y Manuel Marín Rodriguez
 */

class MaxQueue {

private:
    /**
     * @brief Contenedor con la pila
     */
    stack<dato> pil;

public:

    /**
     * @brief Devuelve el tamaño
     * @return Número de datos
     */
    int size() const;

    /**
     * @brief Comprueba si la cola está
     * @return true, si está vacía
     * @return false, en caso contrario
     */
    bool empty() const;

    /**
     * @brief Devuelve el dato del frente (front)
     * @return el dato del frente
     */
    dato front() const;

    /**
     * @brief Mete un dato nuevo
     * @param p lo que se l emete
     * @post El tamaño aumenta en 1
     */
    void push(int p);

    /**
     * @brief Elimina el frente de la pila
     * @post El tamaño disminuye 1
     */
    void pop();
};

/**
 * @brief Saca el maximo y el valor de un dato
 */
ostream & operator<<(ostream & salida, const dato & x);
