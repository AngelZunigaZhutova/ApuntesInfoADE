/**
 * @file maxstack.h
 * @brief  Funciones de la pila
 * @authors Raúl Martínez Bustos y Manuel Marín Rodriguez
 */

#include <stack>
#include <queue>
#include <iostream>

using namespace std;

struct dato {
    int maximo;
    int valor;
};

/**
 * @brief T.D.A MaxStack
 * @authors Raúl Martínez Bustos y Manuel Marín Rodriguez
 */

class MaxStack{
private:
    queue<dato> col;

public:

    /**
     * @brief Devuelve el tamaño de la pila
     * @return Número de elementos que hay
     */
    int size() const;

    /**
     * @brief Comprueba si la pila está vacía
     * @return true, si está vacía
     * @return false, en otro caso
     */
    bool empty() const;

    /**
     * @brief Devuelve el tope de la pila
     * @return El tope del la pila
     * @post El objeto no cambia
     */
    dato top() const;

    /**
     * @brief Inserta un nuevo elemento en el tope y aumenta el máximo
     * @param p lo que se mete
     * @post El tamaño del objeto aumenta 1
     */
    void push(int p);

    /**
     * @brief Elimina el tope la pila (top).
     * @post El tamaño del objeto decrece en q
     */
    void pop();

};

/**
 * @brief Saca el máximo y el valor de la estructura dada
 */
std::ostream & operator<<(std::ostream & salida, const dato & x);