/**
 * @file maxstack.cpp
 * @brief  Funciones de la pila
 * @authors Raúl Martínez Bustos y Manuel Marín Rodriguez
 */

#include <queue>
#include <iostream>
#include "maxstack.h"

using namespace std;

int MaxStack::size() const {
    return col.size();
}

bool MaxStack::empty() const {
    return col.empty();
}

dato MaxStack::top() const{
    return col.front();
}

void MaxStack::push(int p) {
    queue<dato> aux;
    dato x;
    x.maximo = p;
    x.valor = p;

    if(size() != 0) if (top().maximo >= x.maximo) x.maximo = top().maximo;
    aux.push(x);
    while(!empty()){
        aux.push(top());
        pop();
    }
    while(!aux.empty()){
        col.push(aux.front());
        aux.pop();
    }
}

void MaxStack::pop(){
    return col.pop();
}

ostream & operator<<(ostream & salida, const dato & x){
    cout << x.valor << "," << x.maximo;
    return salida;
}