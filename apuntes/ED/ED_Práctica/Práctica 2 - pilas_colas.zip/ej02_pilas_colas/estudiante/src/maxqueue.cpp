/**
 * @file maxqueue.cpp
 * @brief  Funciones de la cola
 * @authors Raúl Martínez Bustos y Manuel Marín Rodriguez
 */

#include "maxqueue.h"

using namespace std;


int MaxQueue::size() const{
    return pil.size();
}

bool MaxQueue::empty() const{
    return pil.empty();
}

dato MaxQueue::front() const{
    return (pil.top());
}

void MaxQueue::push(int p){
    stack<dato> aux;
    for (int i = 0; !empty(); i++){
        aux.push(pil.top());
        pil.pop();
    }
    //Inicializamos valores del dato
    dato x;
    x.valor = p;
    x.maximo = p;
    pil.push(x);

    //Asignamos
    for (int i = 0; !aux.empty(); i++){
        x.valor = aux.top().valor;
        x.maximo = max(pil.top().maximo, x.valor);
        pil.push(x);
        aux.pop();
    }
}

void MaxQueue::pop() {
    pil.pop();
}

ostream & operator<<(ostream & salida, const dato & x){
    cout << x.valor << "," << x.maximo;
    return salida;
}