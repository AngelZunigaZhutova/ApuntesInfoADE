var searchData=
[
  ['paises_2eh_82',['paises.h',['../paises_8h.html',1,'']]],
  ['punto_2eh_83',['punto.h',['../punto_8h.html',1,'']]]
];
