var searchData=
[
  ['r_57',['r',['../structPixel.html#a038ad5b3349e7548d17c5d3bec511b94',1,'Pixel']]],
  ['ruta_58',['Ruta',['../classRuta.html',1,'Ruta'],['../classRuta.html#a1020b0a24a1212f30f4f74284bec3597',1,'Ruta::Ruta()'],['../classRuta.html#ab628a47d76c445e33f5dc91aa15eee6a',1,'Ruta::Ruta(string cod, list&lt; Punto &gt; pts)'],['../classRuta.html#affb87629ff04d8de0583e6d36e0c4b7a',1,'Ruta::Ruta(const Ruta &amp;rut)']]]
];
