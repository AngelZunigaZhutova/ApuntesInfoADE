var searchData=
[
  ['tipo_5fpegado_65',['Tipo_Pegado',['../imagen_8h.html#a573504250cd1401cf4e53b1e756d38f2',1,'imagen.h']]],
  ['tipoimagen_66',['TipoImagen',['../imagenES_8h.html#a8914f6544a484741b05c092d9e7522ed',1,'imagenES.h']]],
  ['transparencia_67',['transparencia',['../structPixel.html#ace9086f9be9b453b5200956ff2098be5',1,'Pixel']]]
];
