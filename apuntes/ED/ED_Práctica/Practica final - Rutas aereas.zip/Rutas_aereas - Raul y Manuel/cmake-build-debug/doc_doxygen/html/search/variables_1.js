var searchData=
[
  ['g_135',['g',['../structPixel.html#a8407845aacf1663d9463475619911686',1,'Pixel']]]
];
