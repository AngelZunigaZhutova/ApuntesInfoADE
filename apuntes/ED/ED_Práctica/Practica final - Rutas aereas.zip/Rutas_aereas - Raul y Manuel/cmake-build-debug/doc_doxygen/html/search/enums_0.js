var searchData=
[
  ['tipo_5fpegado_138',['Tipo_Pegado',['../imagen_8h.html#a573504250cd1401cf4e53b1e756d38f2',1,'imagen.h']]],
  ['tipoimagen_139',['TipoImagen',['../imagenES_8h.html#a8914f6544a484741b05c092d9e7522ed',1,'imagenES.h']]]
];
