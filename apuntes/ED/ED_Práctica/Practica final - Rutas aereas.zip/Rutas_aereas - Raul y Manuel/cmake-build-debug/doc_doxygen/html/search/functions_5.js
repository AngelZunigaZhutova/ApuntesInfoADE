var searchData=
[
  ['getbandera_94',['GetBandera',['../classPais.html#a0ba2a78d564f6ea016e88326b37d6ae3',1,'Pais']]],
  ['getcols_95',['GetCols',['../classImagen.html#abfca20b7eff1e7df00e1918f315e1210',1,'Imagen']]],
  ['getdesc_96',['GetDesc',['../classPunto.html#a315144cc31573b716a4f2b34d17febfa',1,'Punto']]],
  ['getfilas_97',['GetFilas',['../classImagen.html#adc003673730cae2a5eca09b4593ea5db',1,'Imagen']]],
  ['getlat_98',['GetLat',['../classPunto.html#a5673aab73edb4642e766409845797e58',1,'Punto']]],
  ['getlong_99',['GetLong',['../classPunto.html#a01df530cc5ccda34911474154fed536d',1,'Punto']]],
  ['getpais_100',['GetPais',['../classPais.html#aff8c3008945f2dae8d360c700f796243',1,'Pais']]],
  ['getpunto_101',['GetPunto',['../classPais.html#ab0f1ede55db35d15670a1c4210fd013d',1,'Pais::GetPunto()'],['../classRuta.html#aef08a04225e28e188526c2b70586362c',1,'Ruta::GetPunto()']]],
  ['getruta_102',['GetRuta',['../classAlmacen__Rutas.html#afc35028a1f22df1f98cadc47bd1960d2',1,'Almacen_Rutas']]],
  ['getsize_103',['GetSize',['../classImagen.html#a40caaed9c7bc3793a1f9869791b6bc54',1,'Imagen']]],
  ['getsizecolors_104',['GetSizecolors',['../classImagen.html#a1ea910561324cf671812cf91b617766a',1,'Imagen']]]
];
