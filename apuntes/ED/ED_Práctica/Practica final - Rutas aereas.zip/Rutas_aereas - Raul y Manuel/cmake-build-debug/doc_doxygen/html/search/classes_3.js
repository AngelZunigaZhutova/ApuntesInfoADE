var searchData=
[
  ['pais_73',['Pais',['../classPais.html',1,'']]],
  ['paises_74',['Paises',['../classPaises.html',1,'']]],
  ['pixel_75',['Pixel',['../structPixel.html',1,'']]],
  ['punto_76',['Punto',['../classPunto.html',1,'']]]
];
