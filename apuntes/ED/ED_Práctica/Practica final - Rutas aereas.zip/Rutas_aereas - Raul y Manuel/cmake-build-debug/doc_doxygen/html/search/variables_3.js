var searchData=
[
  ['transparencia_137',['transparencia',['../structPixel.html#ace9086f9be9b453b5200956ff2098be5',1,'Pixel']]]
];
