var searchData=
[
  ['ruta_2eh_84',['ruta.h',['../ruta_8h.html',1,'']]]
];
