var searchData=
[
  ['setbandera_127',['SetBandera',['../classPais.html#a2a7496a6a0fa19b0a94a37188413e64a',1,'Pais']]],
  ['setdesc_128',['SetDesc',['../classPunto.html#a7bba52de7c1ad3c3bfe50572c7b830da',1,'Punto']]],
  ['setlat_129',['SetLat',['../classPunto.html#af062c0a183102f209748c1ada16e059d',1,'Punto']]],
  ['setlon_130',['SetLon',['../classPunto.html#ac6252f965204c833d35fd8bf744829a7',1,'Punto']]],
  ['setpais_131',['SetPais',['../classPais.html#a0113f4ad64f3ce77c1642b453d807127',1,'Pais']]],
  ['setpunto_132',['SetPunto',['../classPais.html#a9c019761e5fdad3084741d42644bbbea',1,'Pais']]]
];
