var searchData=
[
  ['begin_85',['begin',['../classAlmacen__Rutas.html#a1aec670f447a48d1b2140e404fa78952',1,'Almacen_Rutas::begin()'],['../classAlmacen__Rutas.html#adf3f0dee31e80a76715e7b8f38ce6281',1,'Almacen_Rutas::begin() const'],['../classPaises.html#a4acf19bd34a7e211114839382d9c9b1a',1,'Paises::begin()'],['../classPaises.html#ae75ed4bf2051d9977a61258b4f1e9fd7',1,'Paises::begin() const'],['../classRuta.html#ab116e5d9799d220b2ba2579af5665b38',1,'Ruta::begin()'],['../classRuta.html#a8ab1e81239cbf04ea067a4402f4f36ea',1,'Ruta::begin() const']]],
  ['borrar_86',['Borrar',['../classAlmacen__Rutas.html#a49fdcc32a80d982d11ecb56949a380e7',1,'Almacen_Rutas::Borrar()'],['../classPaises.html#ab65dee96356d179675990ceb13c1955c',1,'Paises::Borrar()']]]
];
