var searchData=
[
  ['pais_50',['Pais',['../classPais.html',1,'Pais'],['../classPais.html#a16af2b45eb9d07e7292a58556edc9371',1,'Pais::Pais()']]],
  ['paises_51',['Paises',['../classPaises.html',1,'Paises'],['../classPaises.html#a3e50b7718e3e147dc36e2151b93af999',1,'Paises::Paises()']]],
  ['paises_2eh_52',['paises.h',['../paises_8h.html',1,'']]],
  ['pegarimagen_53',['PegarImagen',['../classImagen.html#acd4115ce33e938aca526dc2b73e16db4',1,'Imagen']]],
  ['pixel_54',['Pixel',['../structPixel.html',1,'']]],
  ['punto_55',['Punto',['../classPunto.html',1,'Punto'],['../classPunto.html#a4b8b70b933ff13493ee5ddb3c8532c10',1,'Punto::Punto()'],['../classPunto.html#acf8d62cac9e5c35e40e2bd45b6dc6e1e',1,'Punto::Punto(double lat, double lon, char magicchar)'],['../classPunto.html#ac3e0a5cf97f4025994619e4c987bd0ee',1,'Punto::Punto(const Punto &amp;p)']]],
  ['punto_2eh_56',['punto.h',['../punto_8h.html',1,'']]]
];
