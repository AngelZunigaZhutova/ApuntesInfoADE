var searchData=
[
  ['b_134',['b',['../structPixel.html#a760bdf29b15433d257f119239fcff4d4',1,'Pixel']]]
];
